<?php

namespace App\Roll\Controllers\User;

use App\Core\Controller;
use App\Core\Database;
use App\Helpers\DateHelper;
use PDO;

class RollTokenRegistrationController extends Controller {
    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
            header("Location: " . getenv('APP_URL') . "/roll/login");
            exit;
        }
        if (!isset($_SESSION['roll_cart'])) {
            $_SESSION['roll_cart'] = [];
        }
    }

    public function index($event_id = null) {
        if (!$event_id) {
            header("Location: " . getenv('APP_URL') . "/roll/user/explore");
            exit;
        }

        $db = Database::getInstance()->getConnection();

        $active_token = $_SESSION['active_token_' . $event_id] ?? null;
        $active_invoice = $_SESSION['active_manual_invoice_' . $event_id] ?? null;
        if (!$active_token || !$active_invoice) {
            $_SESSION['flash_message'] = "Sesi Token Anda tidak valid atau telah berakhir.";
            $_SESSION['flash_type'] = "error";
            header("Location: " . getenv('APP_URL') . "/roll/user/explore");
            exit;
        }

        $club_id = $_SESSION['roll_club_id'];

        $stmtAthletes = $db->prepare("SELECT * FROM roll_skaters WHERE club_id = ? ORDER BY skater_name ASC");
        $stmtAthletes->execute([$club_id]);
        $athletes = $stmtAthletes->fetchAll(PDO::FETCH_ASSOC);

        // Fetch All Clubs
        $stmtAllClubs = $db->prepare("SELECT id, club_name FROM roll_clubs ORDER BY club_name ASC");
        $stmtAllClubs->execute();
        $all_clubs = $stmtAllClubs->fetchAll(PDO::FETCH_ASSOC);

        // Fetch Current Club Name
        $stmtMyClub = $db->prepare("SELECT club_name FROM roll_clubs WHERE id = ?");
        $stmtMyClub->execute([$club_id]);
        $club_name = $stmtMyClub->fetchColumn();

        // Get Active Events for Registration
        $stmtEvent = $db->prepare("SELECT * FROM roll_events WHERE id = ?");
        $stmtEvent->execute([$event_id]);
        $event = $stmtEvent->fetch(PDO::FETCH_ASSOC);

        $classes = [];
        if ($event) {
            $stmtClasses = $db->prepare("
                SELECT c.*, a.group_name, a.min_year, a.max_year, d.distance_name, skc.class_name, skc.id as class_cat_id
                FROM roll_event_details c
                JOIN roll_ref_age_groups a ON c.age_group_id = a.id
                JOIN roll_ref_distances d ON c.distance_id = d.id
                JOIN roll_ref_skate_classes skc ON c.skate_class_id = skc.id
                WHERE c.event_id = ?
                ORDER BY a.min_year ASC, c.category_name ASC, d.id ASC
            ");
            $stmtClasses->execute([$event['id']]);
            $classes = $stmtClasses->fetchAll(PDO::FETCH_ASSOC);
        }

        // Fetch registered entries for THIS event and club
        $stmtEntries = $db->prepare("
            SELECT e.id as entry_id, e.race_class_id, e.team_name, e.skater_id, skc.id as class_cat_id, c.age_group_id,
                   s.skater_name, s.gender, s.club_id as athlete_club_id,
                   a.group_name, c.category_name, skc.class_name as skate_class,
                   d.distance_name, c.race_number, c.gender as class_gender,
                   COALESCE(p.status, 'Unpaid') as payment_status
            FROM roll_entries e
            JOIN roll_skaters s ON e.skater_id = s.id
            LEFT JOIN roll_event_details c ON e.race_class_id = c.id
            LEFT JOIN roll_ref_age_groups a ON c.age_group_id = a.id
            LEFT JOIN roll_ref_distances d ON c.distance_id = d.id
            LEFT JOIN roll_ref_skate_classes skc ON c.skate_class_id = skc.id
            LEFT JOIN roll_payments p ON p.club_id = e.club_id AND p.event_id = e.event_id
            WHERE e.event_id = ? AND e.manual_invoice_code = ?
            ORDER BY s.skater_name ASC
        ");
        $stmtEntries->execute([$event_id, $active_invoice]);
        $existingEntries = $stmtEntries->fetchAll(PDO::FETCH_ASSOC);

        $isEditable = !empty(array_filter($existingEntries, fn($e) => in_array($e['payment_status'], ['Unpaid', 'Rejected'])));
        $isLocked = false; // Token mode is always editable until checkout // Terkunci jika semua Pending/Paid
        
        // Fetch token permissions
        $stmtToken = $db->prepare("SELECT allow_individu, allow_team FROM roll_event_tokens WHERE event_id = ? AND club_id = ? AND token_code = ?");
        $stmtToken->execute([$event_id, $club_id, $active_token]);
        $tokenData = $stmtToken->fetch(PDO::FETCH_ASSOC);
        $allow_individu = $tokenData['allow_individu'] ?? 1;
        $allow_team = $tokenData['allow_team'] ?? 1;

        return $this->view('roll/user/token_entries/index', [
            'athletes'        => $athletes,
            'event'           => $event,
            'classes'         => $classes,
            'existingEntries' => $existingEntries,
            'isLocked'        => $isLocked,
            'club_id'         => $club_id,
            'club_name'       => $club_name,
            'all_clubs'       => $all_clubs,
            'allow_individu'  => $allow_individu,
            'allow_team'      => $allow_team,
        ]);
    }

    public function checkEligibility() {
        header('Content-Type: application/json');
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
            exit;
        }

        $skater_id = $_POST['skater_id'] ?? 0;
        $class_id = $_POST['race_class_id'] ?? 0;
        $event_id = $_POST['event_id'] ?? 0;

        if (!$skater_id || !$class_id || !$event_id) {
            echo json_encode(['success' => false, 'message' => 'Data tidak lengkap.']);
            exit;
        }

        $db = Database::getInstance()->getConnection();

        // Ambil Data Atlet
        $stmtA = $db->prepare("SELECT gender, birth_date FROM roll_skaters WHERE id = ?");
        $stmtA->execute([$skater_id]);
        $athlete = $stmtA->fetch(PDO::FETCH_ASSOC);

        if (!$athlete) {
            echo json_encode(['success' => false, 'message' => 'Atlet tidak ditemukan.']);
            exit;
        }

        // Ambil Data Event (untuk tanggal)
        $stmtE = $db->prepare("SELECT event_date_start, allow_pemula_standart_mix FROM roll_events WHERE id = ?");
        $stmtE->execute([$event_id]);
        $event = $stmtE->fetch(PDO::FETCH_ASSOC);

        // Ambil Data Kelas Lomba
        $stmtC = $db->prepare("
            SELECT c.gender as category_name, a.min_year, a.max_year 
            FROM roll_event_details c
            JOIN roll_ref_age_groups a ON c.age_group_id = a.id
            WHERE c.id = ?
        ");
        $stmtC->execute([$class_id]);
        $class = $stmtC->fetch(PDO::FETCH_ASSOC);

        if (!$class) {
            echo json_encode(['success' => false, 'message' => 'Kelas lomba tidak valid.']);
            exit;
        }

        // Validasi 1: Gender vs Category
        $gender = $athlete['gender']; // 'M' atau 'F'
        $category = strtolower($class['category_name']); // 'putra', 'putri', 'mix'

        if ($category === 'putra' && $gender !== 'M') {
            echo json_encode(['success' => false, 'message' => 'Atlet Putri tidak boleh mendaftar di kelas Putra.']);
            exit;
        }
        if ($category === 'putri' && $gender !== 'F') {
            echo json_encode(['success' => false, 'message' => 'Atlet Putra tidak boleh mendaftar di kelas Putri.']);
            exit;
        }

        // Validasi 2: Umur (Age Calculator)
        $age = DateHelper::calculateAge($athlete['birth_date'], $event['event_date_start']);
        if (!empty($athlete['is_pon_veteran'])) {
            $age = 25;
        }
        
        $minAge = $class['min_year'] ?? 0;
        $maxAge = $class['max_year'] ?? 99; // Jika null, anggap max 99 (Dewasa)

        if ($age < $minAge || $age > $maxAge) {
            echo json_encode([
                'success' => false, 
                'message' => "Umur atlet ($age tahun) tidak masuk dalam kategori kelas ini ($minAge - $maxAge tahun)."
            ]);
            exit;
        }

        // Validasi 3: Cek pindah kategori (1 atlet = 1 kategori)
        $stmtCats = $db->prepare("
            SELECT sc.class_name 
            FROM roll_entries e
            JOIN roll_event_details ed ON e.race_class_id = ed.id
            JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
            WHERE e.skater_id = ? AND e.event_id = ?
        ");
        $stmtCats->execute([$skater_id, $event_id]);
        $existingCats = $stmtCats->fetchAll(PDO::FETCH_COLUMN);

        if (!empty($existingCats)) {
            $hasSpeed = false;
            $hasPemula = false;
            $hasStandar = false;
            foreach($existingCats as $c) {
                $cStr = strtolower($c);
                if (strpos($cStr, 'speed') !== false) $hasSpeed = true;
                elseif (strpos($cStr, 'pemula') !== false) $hasPemula = true;
                elseif (strpos($cStr, 'standar') !== false) $hasStandar = true;
            }
            
            $eGroup = strtolower($athlete['athlete_level'] ?? 'pemula');
            if (!empty($athlete['is_pon_veteran'])) {
                $eGroup = 'speed';
            }
            if ($hasSpeed) $eGroup = 'speed';
            elseif ($hasStandar && $eGroup !== 'speed') $eGroup = 'standar';
            
            $stmtTargetCat = $db->prepare("
                SELECT sc.class_name 
                FROM roll_event_details ed
                JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
                WHERE ed.id = ?
            ");
            $stmtTargetCat->execute([$class_id]);
            $targetCat = $stmtTargetCat->fetchColumn();
            $tCatStr = strtolower($targetCat);
            
            $tGroup = '';
            if (strpos($tCatStr, 'speed') !== false) $tGroup = 'speed';
            elseif (strpos($tCatStr, 'standar') !== false) $tGroup = 'standar';
            elseif (strpos($tCatStr, 'pemula') !== false) $tGroup = 'pemula';
            
            if ($eGroup && $tGroup && $eGroup !== $tGroup) {
                $allowMix = !empty($event['allow_pemula_standart_mix']);
                if ($allowMix) {
                    $isMixable = ($eGroup === 'pemula' && $tGroup === 'standar');
                    if (!$isMixable) {
                        echo json_encode([
                            'success' => false,
                            'message' => "Atlet sudah terdaftar di " . strtoupper($eGroup) . ", tidak bisa didaftarkan ke " . strtoupper($tGroup) . "."
                        ]);
                        exit;
                    }
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => "Atlet sudah terdaftar di " . strtoupper($eGroup) . ", tidak bisa didaftarkan ke " . strtoupper($tGroup) . "."
                    ]);
                    exit;
                }
            }
        }

        // Lolos Semua
        echo json_encode(['success' => true, 'message' => 'Atlet memenuhi syarat!']);
        exit;
    }

    public function addEntry() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: " . getenv('APP_URL') . "/roll/user/explore");
            exit;
        }

        $skater_ids = isset($_POST['skater_id']) ? (is_array($_POST['skater_id']) ? $_POST['skater_id'] : [$_POST['skater_id']]) : [];
        $race_class_ids = isset($_POST['race_class_id']) ? (is_array($_POST['race_class_id']) ? $_POST['race_class_id'] : [$_POST['race_class_id']]) : [];
        $event_id     = (int)($_POST['event_id'] ?? 0);
        $club_id      = (int)($_SESSION['roll_club_id'] ?? 0);
        $team_name    = isset($_POST['team_name']) ? trim($_POST['team_name']) : null;
        $is_team_reg  = !empty($team_name);

        $entry_type = $_POST['entry_type'] ?? 'individu';
        $active_invoice = $_SESSION['active_manual_invoice_' . $event_id] ?? null;
        
        if (empty($skater_ids) || empty($race_class_ids) || !$event_id) {
            $_SESSION['flash_message'] = "Data tidak lengkap.";
            $_SESSION['flash_type'] = "error";
            header("Location: " . getenv('APP_URL') . "/roll/user/token_registration/index/" . $event_id . "?form=" . $entry_type);
            exit;
        }

        $db = \App\Core\Database::getInstance()->getConnection();
        
        $old_team_name = $_POST['old_team_name'] ?? null;
        $old_race_class_id = (int)($_POST['old_race_class_id'] ?? 0);
        if ($is_team_reg && !empty($old_team_name) && $old_race_class_id > 0) {
            // Hapus tim lama sebelum menyimpan yang baru
            $stmtDelSel = $db->prepare("
                SELECT e.id FROM roll_entries e
                WHERE e.team_name = ? AND e.race_class_id = ? AND e.event_id = ? AND e.club_id = ? 
                  AND e.manual_invoice_code = ?
            ");
            $stmtDelSel->execute([$old_team_name, $old_race_class_id, $event_id, $club_id, $active_invoice]);
            $delEntries = $stmtDelSel->fetchAll(\PDO::FETCH_ASSOC);
            if (count($delEntries) > 0) {
                $ids = array_column($delEntries, 'id');
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $db->prepare("DELETE FROM roll_entries WHERE id IN ($placeholders)")->execute($ids);
            }
        }

        // Bypass check status event for Token
        
        // Fetch event limits
        $stmtLimit = $db->prepare("SELECT limit_speed_ind, limit_speed_team, limit_std_ind, limit_std_team, limit_pemula_ind, limit_pemula_team, allow_pemula_standart_mix FROM roll_events WHERE id = ?");
        $stmtLimit->execute([$event_id]);
        $eventLimits = $stmtLimit->fetch(PDO::FETCH_ASSOC);
        
        $successCount = 0;
        $failMessages = [];

        $teamFail = false;
        if ($is_team_reg) { $db->beginTransaction(); }

        foreach ($skater_ids as $skater_id) {
            $skater_id = (int)$skater_id;
            
            // Dapatkan info atlet (hilangkan constraint club_id untuk mendukung Mix-Club)
            $stmtOwn = $db->prepare("SELECT skater_name, birth_date, gender, is_pon_veteran FROM roll_skaters WHERE id = ?");
            $stmtOwn->execute([$skater_id]);
            $skater = $stmtOwn->fetch(PDO::FETCH_ASSOC);
            if (!$skater) continue;
            
            $skater_name = $skater['skater_name'];

            // Get current counts for this skater in this event by category
            $stmtCount = $db->prepare("
                SELECT 
                    sc.class_name,
                    SUM(CASE WHEN e.team_name IS NULL OR e.team_name = '' THEN 1 ELSE 0 END) as indv_count,
                    SUM(CASE WHEN e.team_name IS NOT NULL AND e.team_name != '' THEN 1 ELSE 0 END) as team_count
                FROM roll_entries e
                JOIN roll_event_details ed ON e.race_class_id = ed.id
                JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
                WHERE e.skater_id = ? AND e.event_id = ?
                GROUP BY sc.class_name
            ");
            $stmtCount->execute([$skater_id, $event_id]);
            $countRows = $stmtCount->fetchAll(PDO::FETCH_ASSOC);
            
            $currIndvCounts = ['speed' => 0, 'standar' => 0, 'pemula' => 0];
            $currTeamCounts = ['speed' => 0, 'standar' => 0, 'pemula' => 0];
            
            foreach ($countRows as $row) {
                $cName = strtolower($row['class_name']);
                if (strpos($cName, 'speed') !== false) {
                    $currIndvCounts['speed'] += (int)$row['indv_count'];
                    $currTeamCounts['speed'] += (int)$row['team_count'];
                } elseif (strpos($cName, 'standar') !== false) {
                    $currIndvCounts['standar'] += (int)$row['indv_count'];
                    $currTeamCounts['standar'] += (int)$row['team_count'];
                } elseif (strpos($cName, 'pemula') !== false) {
                    $currIndvCounts['pemula'] += (int)$row['indv_count'];
                    $currTeamCounts['pemula'] += (int)$row['team_count'];
                }
            }

            // AUTO INJECT MANDATORY CLASSES
            if (!$is_team_reg && !empty($race_class_ids)) {
                $stmtC = $db->prepare("SELECT skate_class_id FROM roll_event_details WHERE id = ?");
                $stmtC->execute([$race_class_ids[0]]);
                $firstClass = $stmtC->fetch(PDO::FETCH_ASSOC);
                
                if ($firstClass) {
                    $skate_class_id = $firstClass['skate_class_id'];
                    $stmtEvDate = $db->prepare("SELECT event_date_start FROM roll_events WHERE id = ?");
                    $stmtEvDate->execute([$event_id]);
                    $evDate = $stmtEvDate->fetchColumn();
                    
                    $skaterAge = \App\Helpers\DateHelper::calculateAge($skater['birth_date'], $evDate);
                    if (!empty($skater['is_pon_veteran'])) {
                        $skaterAge = 25; // Paksa ke KU Senior
                    }
                    
                    $stmtMandatory = $db->prepare("
                        SELECT c.id 
                        FROM roll_event_details c
                        JOIN roll_ref_age_groups a ON c.age_group_id = a.id
                        WHERE c.event_id = ? 
                          AND c.skate_class_id = ? 
                          AND c.race_number LIKE '%*%'
                          AND ? >= a.min_year AND ? <= a.max_year
                          AND (LOWER(c.gender) = 'campuran' 
                               OR (LOWER(c.gender) = 'putra' AND ? = 'M') 
                               OR (LOWER(c.gender) = 'putri' AND ? = 'F'))
                    ");
                    $stmtMandatory->execute([$event_id, $skate_class_id, $skaterAge, $skaterAge, $skater['gender'], $skater['gender']]);
                    $mandatoryIds = $stmtMandatory->fetchAll(PDO::FETCH_COLUMN);
                    
                    foreach ($mandatoryIds as $mid) {
                        if (!in_array($mid, $race_class_ids)) {
                            array_unshift($race_class_ids, $mid);
                        }
                    }
                }
            }

            foreach ($race_class_ids as $race_class_id) {
                $race_class_id = (int)$race_class_id;

                // Determine target category for limits
                $stmtTargetCat = $db->prepare("
                    SELECT sc.class_name 
                    FROM roll_event_details ed
                    JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
                    WHERE ed.id = ?
                ");
                $stmtTargetCat->execute([$race_class_id]);
                $targetCatStr = strtolower((string)$stmtTargetCat->fetchColumn());
                
                $maxIndv = 99;
                $maxTeam = 99;
                $targetGroup = '';
                if (strpos($targetCatStr, 'speed') !== false) {
                    $targetGroup = 'speed';
                    $maxIndv = $eventLimits['limit_speed_ind'] ?? 99;
                    $maxTeam = $eventLimits['limit_speed_team'] ?? 99;
                } elseif (strpos($targetCatStr, 'standar') !== false) {
                    $targetGroup = 'standar';
                    $maxIndv = $eventLimits['limit_std_ind'] ?? 99;
                    $maxTeam = $eventLimits['limit_std_team'] ?? 99;
                } elseif (strpos($targetCatStr, 'pemula') !== false) {
                    $targetGroup = 'pemula';
                    $maxIndv = $eventLimits['limit_pemula_ind'] ?? 99;
                    $maxTeam = $eventLimits['limit_pemula_team'] ?? 99;
                }

                // Check limits
                if ($is_team_reg && isset($currTeamCounts[$targetGroup]) && $currTeamCounts[$targetGroup] >= $maxTeam) {
                    $failMessages[] = "$skater_name mencapai batas maksimal Team ($maxTeam) untuk kategori " . ucfirst($targetGroup) . ".";
                    if ($is_team_reg) { $teamFail = true; } continue; // Skip this race for this skater
                }
                if (!$is_team_reg && isset($currIndvCounts[$targetGroup]) && $currIndvCounts[$targetGroup] >= $maxIndv) {
                    $failMessages[] = "$skater_name mencapai batas maksimal Individu ($maxIndv) untuk kategori " . ucfirst($targetGroup) . ".";
                    continue; // Skip this race for this skater
                }

                // Cek duplikasi
                $stmtDup = $db->prepare("SELECT id FROM roll_entries WHERE skater_id = ? AND race_class_id = ? AND event_id = ?");
                $stmtDup->execute([$skater_id, $race_class_id, $event_id]);
                if ($stmtDup->fetch()) {
                    $failMessages[] = "$skater_name sudah terdaftar di nomor lomba ini.";
                    if ($is_team_reg) { $teamFail = true; } continue;
                }
                
                // Cek pindah kategori (1 atlet hanya 1 kategori: Speed/Standart/Pemula)
                $stmtCats = $db->prepare("
                    SELECT sc.class_name 
                    FROM roll_entries e
                    JOIN roll_event_details ed ON e.race_class_id = ed.id
                    JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
                    WHERE e.skater_id = ? AND e.event_id = ?
                ");
                $stmtCats->execute([$skater_id, $event_id]);
                $existingCats = $stmtCats->fetchAll(PDO::FETCH_COLUMN);

                if (!empty($existingCats)) {
                    $hasSpeed = false;
                    $hasPemula = false;
                    $hasStandar = false;
                    foreach($existingCats as $c) {
                        $cStr = strtolower($c);
                        if (strpos($cStr, 'speed') !== false) $hasSpeed = true;
                        elseif (strpos($cStr, 'pemula') !== false) $hasPemula = true;
                        elseif (strpos($cStr, 'standar') !== false) $hasStandar = true;
                    }
                    
                    $eGroup = strtolower($skater['athlete_level'] ?? 'pemula');
                    if (!empty($skater['is_pon_veteran'])) {
                        $eGroup = 'speed';
                    }
                    if ($hasSpeed) $eGroup = 'speed';
                    elseif ($hasStandar && $eGroup !== 'speed') $eGroup = 'standar';
                    
                    $tCatStr = strtolower($targetCatStr);
                    
                    $tGroup = '';
                    if (strpos($tCatStr, 'speed') !== false) $tGroup = 'speed';
                    elseif (strpos($tCatStr, 'standar') !== false) $tGroup = 'standar';
                    elseif (strpos($tCatStr, 'pemula') !== false) $tGroup = 'pemula';
                    
                    if ($eGroup && $tGroup && $eGroup !== $tGroup) {
                        $allowMix = !empty($eventLimits['allow_pemula_standart_mix']);
                        if ($allowMix) {
                            $isMixable = ($eGroup === 'pemula' && $tGroup === 'standar');
                            if (!$isMixable) {
                                $failMessages[] = "$skater_name tidak bisa dicampur antara " . strtoupper($eGroup) . " dan " . strtoupper($tGroup) . ".";
                                if ($is_team_reg) { $teamFail = true; } continue; 
                            }
                        } else {
                            $failMessages[] = "$skater_name tidak bisa dicampur antara " . strtoupper($eGroup) . " dan " . strtoupper($tGroup) . ".";
                            if ($is_team_reg) { $teamFail = true; } continue; 
                        }
                    }
                }

                // Ambil id jarak
                $stmtDist = $db->prepare("SELECT d.id FROM roll_event_details c JOIN roll_ref_distances d ON c.distance_id = d.id WHERE c.id = ?");
                $stmtDist->execute([$race_class_id]);
                $distance_id = $stmtDist->fetchColumn() ?: null;

                // Save
                $stmtInsert = $db->prepare("INSERT INTO roll_entries (club_id, event_id, skater_id, race_class_id, distance_id, team_name, is_manual, manual_invoice_code, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())");
                if ($stmtInsert->execute([$club_id, $event_id, $skater_id, $race_class_id, $distance_id, $team_name, $active_invoice])) {
                    $successCount++;
                    if ($targetGroup) {
                        if ($is_team_reg) { $currTeamCounts[$targetGroup]++; } else { $currIndvCounts[$targetGroup]++; }
                    }
                }
            }
        }
        
        if ($is_team_reg) {
            if ($teamFail || empty($successCount)) {
                $db->rollBack();
                $successCount = 0;
                $failMessages[] = "Seluruh pendaftaran tim dibatalkan karena ada anggota yang tidak memenuhi syarat.";
            } else {
                $db->commit();
            }
        }

        if ($successCount > 0) {
            $msg = "Berhasil mendaftarkan $successCount entri.";
            if (!empty($failMessages)) {
                $msg .= " Namun ada beberapa gagal: " . implode(" ", array_unique($failMessages));
            }
            $_SESSION['flash_message'] = $msg;
            $_SESSION['flash_type'] = "success";
        } else {
            $_SESSION['flash_message'] = "Gagal mendaftar. " . (!empty($failMessages) ? implode(" ", array_unique($failMessages)) : "Pastikan data valid.");
            $_SESSION['flash_type'] = "error";
        }

        header("Location: " . getenv('APP_URL') . "/roll/user/token_registration/index/" . $event_id . "?form=" . $entry_type);
        exit;
    }

    public function removeEntry($entry_id = null) {
        $club_id = (int)($_SESSION['roll_club_id'] ?? 0);
        $db = \App\Core\Database::getInstance()->getConnection();

        // Pastikan entry milik klub ini
        $stmt = $db->prepare("
            SELECT e.id, e.event_id 
            FROM roll_entries e
            WHERE e.id = ? AND e.club_id = ?
        ");
        $stmt->execute([$entry_id, $club_id]);
        $entry = $stmt->fetch(\PDO::FETCH_ASSOC);

        if ($entry) {
            $active_invoice = $_SESSION['active_manual_invoice_' . $entry['event_id']] ?? null;
            $stmtCheck = $db->prepare("SELECT id FROM roll_entries WHERE id = ? AND manual_invoice_code = ?");
            $stmtCheck->execute([$entry['id'], $active_invoice]);
            if (!$stmtCheck->fetch()) {
                $_SESSION['flash_message'] = "Entry tidak dapat dihapus karena sudah tidak aktif/diproses.";
                $_SESSION['flash_type'] = "error";
                header("Location: " . getenv('APP_URL') . "/roll/user/explore");
                exit;
            }

            // Bypass check status event for Token

            $db->prepare("DELETE FROM roll_entries WHERE id = ?")->execute([$entry['id']]);
            $_SESSION['flash_message'] = "Pendaftaran dibatalkan.";
            $_SESSION['flash_type'] = "success";
            header("Location: " . getenv('APP_URL') . "/roll/user/token_registration/index/" . $entry['event_id']);
        } else {
            $_SESSION['flash_message'] = "Entry tidak dapat dihapus (sudah diproses atau tidak ditemukan).";
            $_SESSION['flash_type'] = "error";
            header("Location: " . getenv('APP_URL') . "/roll/user/explore");
        }
        exit;
    }

    public function removeTeam() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: " . getenv('APP_URL') . "/roll/user/explore");
            exit;
        }

        $club_id = (int)($_SESSION['roll_club_id'] ?? 0);
        $event_id = (int)($_POST['event_id'] ?? 0);
        $team_name = $_POST['team_name'] ?? '';
        $race_class_id = (int)($_POST['race_class_id'] ?? 0);

        if (!$event_id || !$team_name || !$race_class_id) {
            $_SESSION['flash_message'] = "Data tidak valid.";
            $_SESSION['flash_type'] = "error";
            header("Location: " . getenv('APP_URL') . "/roll/user/explore");
            exit;
        }

        $db = \App\Core\Database::getInstance()->getConnection();
        $active_invoice = $_SESSION['active_manual_invoice_' . $event_id] ?? null;

        // Pastikan tim milik klub ini dan masih di invoice aktif
        $stmt = $db->prepare("
            SELECT e.id
            FROM roll_entries e
            WHERE e.team_name = ? AND e.race_class_id = ? AND e.event_id = ? AND e.club_id = ? 
              AND e.manual_invoice_code = ?
        ");
        $stmt->execute([$team_name, $race_class_id, $event_id, $club_id, $active_invoice]);
        $entries = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        if (count($entries) > 0) {
            $ids = array_column($entries, 'id');
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM roll_entries WHERE id IN ($placeholders)")->execute($ids);
            
            $_SESSION['flash_message'] = "Tim beserta seluruh anggotanya berhasil dihapus.";
            $_SESSION['flash_type'] = "success";
            header("Location: " . getenv('APP_URL') . "/roll/user/token_registration/index/" . $event_id);
        } else {
            $_SESSION['flash_message'] = "Tim tidak dapat dihapus (sudah diproses atau tidak ditemukan).";
            $_SESSION['flash_type'] = "error";
            header("Location: " . getenv('APP_URL') . "/roll/user/token_registration/index/" . $event_id);
        }
        exit;
    }

    public function get_athlete_entries() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
            echo json_encode([]);
            exit;
        }

        $db = Database::getInstance()->getConnection();
        $skater_id = (int)($_GET['skater_id'] ?? 0);
        $event_id = (int)($_GET['event_id'] ?? 0);
        $club_id = (int)($_SESSION['roll_club_id'] ?? 0);

        if ($skater_id == 0 || $event_id == 0) {
            echo json_encode(['race_class_ids' => [], 'locked_cat_id' => null]);
            exit;
        }
        
        // Verify skater belongs to club
        $stmtCheck = $db->prepare("SELECT id FROM roll_skaters WHERE id = ? AND club_id = ?");
        $stmtCheck->execute([$skater_id, $club_id]);
        if (!$stmtCheck->fetchColumn()) {
            echo json_encode(['race_class_ids' => [], 'locked_cat_id' => null]);
            exit;
        }

        // Ambil semua entri atlet di event ini
        $stmt = $db->prepare("
            SELECT e.race_class_id, ed.skate_class_id, d.distance_name, skc.id as class_cat_id
            FROM roll_entries e
            JOIN roll_event_details ed ON e.race_class_id = ed.id
            JOIN roll_ref_distances d ON ed.distance_id = d.id
            JOIN roll_ref_skate_classes skc ON ed.skate_class_id = skc.id
            WHERE e.skater_id = ? AND e.event_id = ?
        ");
        $stmt->execute([$skater_id, $event_id]);
        $entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $race_class_ids = [];
        $locked_cat_id = null;

        foreach ($entries as $ent) {
            $dName = strtolower($ent['distance_name']);
            // Abaikan team/relay dari locked category logic
            if (strpos($dName, 'relay') !== false || strpos($dName, 'team') !== false || strpos($dName, 'pair') !== false) {
                continue;
            }
            $race_class_ids[] = $ent['race_class_id'];
            if (!$locked_cat_id) {
                $locked_cat_id = $ent['class_cat_id']; // Kunci kategori dari entri pertama
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'race_class_ids' => $race_class_ids,
            'locked_cat_id' => $locked_cat_id
        ]);
        exit;
    }


    public function get_athletes_by_club() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
            echo json_encode([]);
            exit;
        }
        $clubId = (int)($_GET['club_id'] ?? 0);
        $eventId = (int)($_GET['event_id'] ?? 0);

        if (!$clubId) {
            echo json_encode([]);
            exit;
        }

        $db = \App\Core\Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT id, skater_name, gender, birth_date FROM roll_skaters WHERE club_id = ? ORDER BY skater_name ASC");
        $stmt->execute([$clubId]);
        $athletes = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        if ($eventId) {
            // Cari grup kelas (speed/standar/pemula) jika atlet sudah pernah didaftarkan
            $stmtGroup = $db->prepare("
                SELECT skc.class_name 
                FROM roll_entries e
                JOIN roll_event_details ed ON e.race_class_id = ed.id
                JOIN roll_ref_skate_classes skc ON ed.skate_class_id = skc.id
                WHERE e.event_id = ? AND e.skater_id = ?
                LIMIT 1
            ");
            
            foreach ($athletes as &$athlete) {
                $stmtGroup->execute([$eventId, $athlete['id']]);
                $catName = $stmtGroup->fetchColumn();
                $athlete['locked_group'] = '';
                if ($catName) {
                    $catStr = strtolower($catName);
                    if (strpos($catStr, 'speed') !== false) $athlete['locked_group'] = 'speed';
                    elseif (strpos($catStr, 'standar') !== false) $athlete['locked_group'] = 'standar';
                    elseif (strpos($catStr, 'pemula') !== false) $athlete['locked_group'] = 'pemula';
                }
            }
        }

        echo json_encode($athletes);
        exit;
    }
}
