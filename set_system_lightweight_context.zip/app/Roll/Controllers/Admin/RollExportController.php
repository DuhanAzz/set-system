<?php

namespace App\Roll\Controllers\Admin;

use App\Core\Controller;
use App\Core\Database;
use PDO;

class RollExportController extends Controller {

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header("Location: " . getenv('APP_URL') . "/roll/login");
            exit;
        }
    }

    public function index() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;

        if ($eventId == 0) {
            $_SESSION['flash_message'] = "Pilih Event terlebih dahulu!";
            $_SESSION['flash_type'] = "warning";
            header("Location: " . getenv('APP_URL') . "/roll/admin/dashboard");
            exit;
        }

        $stmtCats = $db->prepare("
            SELECT DISTINCT sc.class_name 
            FROM roll_event_details ed 
            JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id 
            WHERE ed.event_id = ? 
            ORDER BY sc.class_name
        ");
        $stmtCats->execute([$eventId]);
        $categories = $stmtCats->fetchAll(PDO::FETCH_COLUMN);

        return $this->view('roll/admin/export/index', [
            'eventId' => $eventId,
            'categories' => $categories
        ]);
    }

    public function generate_master_reference() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;

        if ($eventId == 0) {
            die("Event not selected.");
        }

        $stmtClasses = $db->prepare("
            SELECT ed.id, ed.race_number, d.distance_name, a.group_name, ed.gender, sc.class_name, ed.category_name 
            FROM roll_event_details ed
            LEFT JOIN roll_ref_distances d ON ed.distance_id = d.id
            LEFT JOIN roll_ref_age_groups a ON ed.age_group_id = a.id
            LEFT JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
            WHERE ed.event_id = ?
            ORDER BY CAST(ed.race_number AS UNSIGNED) ASC, ed.race_number ASC, ed.gender DESC, a.id ASC
        ");
        $stmtClasses->execute([$eventId]);
        $classes = $stmtClasses->fetchAll(PDO::FETCH_ASSOC);

        $stmtRounds = $db->prepare("SELECT DISTINCT round FROM roll_pelotons WHERE event_id = ? AND race_class_id = ? ORDER BY CASE round WHEN 'Kualifikasi' THEN 1 WHEN 'Perempat Final' THEN 2 WHEN 'Semi Final' THEN 3 WHEN 'Final' THEN 4 ELSE 5 END");

        $stmtData = $db->prepare("
            SELECT e.bib_number, p.heat_name, s.skater_name, r.time, e.team_name, c.club_name
            FROM roll_pelotons p
            JOIN roll_entries e ON p.skater_id = e.skater_id AND p.race_class_id = e.race_class_id AND p.event_id = e.event_id
            JOIN roll_skaters s ON p.skater_id = s.id
            LEFT JOIN roll_clubs c ON s.club_id = c.id
            LEFT JOIN roll_event_results r ON p.event_id = r.event_id AND p.race_class_id = r.race_class_id AND p.skater_id = r.skater_id AND p.heat_name = r.heat_name AND p.round = r.round
            WHERE p.event_id = ? AND p.race_class_id = ? AND p.round = ?
            ORDER BY CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC
        ");

        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="Event_' . $eventId . '_Master_Reference_Lynx.xls"');

        echo '<?xml version="1.0"?>' . "\n";
        echo '<?mso-application progid="Excel.Sheet"?>' . "\n";
        echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">' . "\n";
        echo ' <Styles>' . "\n";
        echo '  <Style ss:ID="Default" ss:Name="Normal"><Alignment ss:Vertical="Bottom"/><Borders/><Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/><Interior/><NumberFormat/><Protection/></Style>' . "\n";
        echo '  <Style ss:ID="sHeader"><Alignment ss:Horizontal="Center" ss:Vertical="Center"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders><Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#FFFFFF" ss:Bold="1"/><Interior ss:Color="#1E3A8A" ss:Pattern="Solid"/></Style>' . "\n";
        echo '  <Style ss:ID="sInfoTitle"><Alignment ss:Vertical="Center"/><Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="12" ss:Color="#000000" ss:Bold="1"/><Interior ss:Color="#E2E8F0" ss:Pattern="Solid"/></Style>' . "\n";
        echo ' </Styles>' . "\n";

        // SHEET 1: Referensi File CSV Lynx
        echo ' <Worksheet ss:Name="Referensi CSV Lynx">' . "\n";
        echo '  <Table>' . "\n";
        echo '   <Column ss:Width="80"/>' . "\n";
        echo '   <Column ss:Width="120"/>' . "\n";
        echo '   <Column ss:Width="450"/>' . "\n";
        echo '   <Row>' . "\n";
        echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">NO LOMBA</Data></Cell>' . "\n";
        echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">BABAK</Data></Cell>' . "\n";
        echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">EKSPEKTASI NAMA FILE (LYNX)</Data></Cell>' . "\n";
        echo '   </Row>' . "\n";

        foreach ($classes as $raceInfo) {
            $classId = $raceInfo['id'];
            $stmtRounds->execute([$eventId, $classId]);
            $rounds = $stmtRounds->fetchAll(PDO::FETCH_COLUMN);

            if (empty($rounds)) {
                $rounds = ['Kualifikasi']; // Minimal 1 baris meski belum digenerate pelotonnya
            }

            foreach ($rounds as $round) {
                $isEksebisi = (($raceInfo['category_name'] ?? '') === 'EKSEBISI');
                
                $raceLabel = "R" . str_pad($raceInfo['race_number'], 3, '0', STR_PAD_LEFT) . "_" . ($raceInfo['class_name'] ?? 'Umum') . "_" . ($raceInfo['distance_name'] ?? '') . "_" . ($raceInfo['group_name'] ?? '') . "_" . ($raceInfo['gender'] ?? '');
                if ($isEksebisi) {
                    $raceLabel .= "_Eksebisi";
                }
                $filenameLabel = $raceLabel . "_" . $round;
                $safeFilename = preg_replace('/[^A-Za-z0-9_]/', '_', str_replace(' ', '_', $filenameLabel)) . '.csv';

                echo '   <Row>' . "\n";
                echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($raceInfo['race_number']) . '</Data></Cell>' . "\n";
                echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($round) . '</Data></Cell>' . "\n";
                echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($safeFilename) . '</Data></Cell>' . "\n";
                echo '   </Row>' . "\n";
            }
        }
        
        echo '  </Table>' . "\n";
        echo ' </Worksheet>' . "\n";

        // SHEET 2: Kumpulan Start List
        echo ' <Worksheet ss:Name="Kumpulan Start List">' . "\n";
        echo '  <Table>' . "\n";
        echo '   <Column ss:Width="80"/>' . "\n";
        echo '   <Column ss:Width="80"/>' . "\n";
        echo '   <Column ss:Width="80"/>' . "\n";
        echo '   <Column ss:Width="250"/>' . "\n";
        echo '   <Column ss:Width="200"/>' . "\n";

        foreach ($classes as $raceInfo) {
            $classId = $raceInfo['id'];
            $stmtRounds->execute([$eventId, $classId]);
            $rounds = $stmtRounds->fetchAll(PDO::FETCH_COLUMN);

            if (empty($rounds)) continue;

            $fullRaceTitle = "R" . str_pad($raceInfo['race_number'], 3, '0', STR_PAD_LEFT) . " - " . ($raceInfo['distance_name'] ?? '') . " - " . ($raceInfo['group_name'] ?? '') . " - " . ($raceInfo['gender'] ?? 'CAMPURAN') . " | Kategori: " . ($raceInfo['class_name'] ?? 'Umum');

            foreach ($rounds as $round) {
                $stmtData->execute([$eventId, $classId, $round]);
                $rows = $stmtData->fetchAll(PDO::FETCH_ASSOC);

                if (empty($rows)) continue;

                $roundTitle = $fullRaceTitle . " (" . strtoupper($round) . ")";

                // Print INFO header
                echo '   <Row>' . "\n";
                echo '    <Cell ss:StyleID="sInfoTitle"><Data ss:Type="String">INFO</Data></Cell>' . "\n";
                echo '    <Cell ss:StyleID="sInfoTitle" ss:MergeAcross="3"><Data ss:Type="String">' . htmlspecialchars($roundTitle) . '</Data></Cell>' . "\n";
                echo '   </Row>' . "\n";

                // Print Headers
                echo '   <Row>' . "\n";
                echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">BIB</Data></Cell>' . "\n";
                echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">TIME</Data></Cell>' . "\n";
                echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">HEAT</Data></Cell>' . "\n";
                echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">NAME</Data></Cell>' . "\n";
                echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">CLUB</Data></Cell>' . "\n";
                echo '   </Row>' . "\n";

                // Print Athletes
                foreach ($rows as $r) {
                    $timeFmt = $r['time'] ? str_replace(':', '.', $r['time']) : '';
                    echo '   <Row>' . "\n";
                    echo '    <Cell><Data ss:Type="String">' . htmlspecialchars(str_pad($r['bib_number'] ?? '', 3, '0', STR_PAD_LEFT)) . '</Data></Cell>' . "\n";
                    echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($timeFmt) . '</Data></Cell>' . "\n";
                    echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($r['heat_name'] ?? '') . '</Data></Cell>' . "\n";
                    echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($r['skater_name'] ?? '') . '</Data></Cell>' . "\n";
                    echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($r['club_name'] ?? '-') . '</Data></Cell>' . "\n";
                    echo '   </Row>' . "\n";
                }
                
                // Print Empty Row to separate races
                echo '   <Row><Cell><Data ss:Type="String"></Data></Cell></Row>' . "\n";
            }
        }
        
        echo '  </Table>' . "\n";
        echo ' </Worksheet>' . "\n";
        echo '</Workbook>';
        exit;
    }

    public function generate_start_list() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;

        if ($eventId == 0) {
            die("Event not selected.");
        }

        $stmtClasses = $db->prepare("
            SELECT ed.id, ed.race_number, d.distance_name, a.group_name, ed.gender, sc.class_name, ed.category_name 
            FROM roll_event_details ed
            LEFT JOIN roll_ref_distances d ON ed.distance_id = d.id
            LEFT JOIN roll_ref_age_groups a ON ed.age_group_id = a.id
            LEFT JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
            WHERE ed.event_id = ?
            ORDER BY CAST(ed.race_number AS UNSIGNED) ASC, ed.race_number ASC, ed.gender DESC, a.id ASC
        ");
        $stmtClasses->execute([$eventId]);
        $classes = $stmtClasses->fetchAll(PDO::FETCH_ASSOC);

        $stmtRounds = $db->prepare("SELECT DISTINCT round FROM roll_pelotons WHERE event_id = ? AND race_class_id = ?");

        $zip = new \ZipArchive();
        
        $zipDir = __DIR__ . '/../../../../public/uploads/export';
        if (!is_dir($zipDir)) {
            mkdir($zipDir, 0777, true);
        }
        $zipFilename = $zipDir . '/Event_' . $eventId . '_All_CSV_' . time() . '.zip';

        if ($zip->open($zipFilename, \ZipArchive::CREATE) !== TRUE) {
            die("Cannot create zip file in " . $zipFilename);
        }

        $hasFiles = false;

        foreach ($classes as $raceInfo) {
            $classId = $raceInfo['id'];
            $stmtRounds->execute([$eventId, $classId]);
            $rounds = $stmtRounds->fetchAll(PDO::FETCH_COLUMN);

            if (empty($rounds)) continue;

            $dn = strtolower($raceInfo['distance_name'] ?? '');
            $raceFormat = 'DTT';
            if (strpos($dn, 'eliminasi') !== false) {
                $raceFormat = 'ELIMINASI';
            } elseif (strpos($dn, 'ptp') !== false || strpos($dn, 'point') !== false) {
                $raceFormat = 'PTP';
            }

            if ($raceFormat === 'ELIMINASI') {
                $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN '99:99.999' ELSE r.time END ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
            } else if ($raceFormat === 'DTT') {
                $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN 1 ELSE 0 END ASC, REPLACE(r.time, ':', '.') ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
            } else {
                $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, r.point DESC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN 1 ELSE 0 END ASC, REPLACE(r.time, ':', '.') ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
            }

            $stmtData = $db->prepare("
                SELECT e.bib_number, p.heat_name, s.skater_name, r.time, e.team_name, c.club_name
                FROM roll_pelotons p
                JOIN roll_entries e ON p.skater_id = e.skater_id AND p.race_class_id = e.race_class_id AND p.event_id = e.event_id
                JOIN roll_skaters s ON p.skater_id = s.id
                LEFT JOIN roll_clubs c ON s.club_id = c.id
                LEFT JOIN roll_event_results r ON p.event_id = r.event_id AND p.race_class_id = r.race_class_id AND p.skater_id = r.skater_id AND p.heat_name = r.heat_name AND p.round = r.round
                WHERE p.event_id = ? AND p.race_class_id = ? AND p.round = ?
                $orderBy
            ");

            foreach ($rounds as $round) {
                $stmtData->execute([$eventId, $classId, $round]);
                $rows = $stmtData->fetchAll(PDO::FETCH_ASSOC);

                if (empty($rows)) continue;

                $raceLabel = "R" . str_pad($raceInfo['race_number'], 3, '0', STR_PAD_LEFT) . "_" . ($raceInfo['class_name'] ?? 'Umum') . "_" . ($raceInfo['distance_name'] ?? '') . "_" . ($raceInfo['group_name'] ?? '') . "_" . ($raceInfo['gender'] ?? '');
                if (($raceInfo['category_name'] ?? '') === 'EKSEBISI') {
                    $raceLabel .= "_Eksebisi";
                }
                $filenameLabel = $raceLabel . "_" . $round;
                $safeFilename = preg_replace('/[^A-Za-z0-9_]/', '_', str_replace(' ', '_', $filenameLabel)) . '.csv';

                $fullRaceTitle = "R" . str_pad($raceInfo['race_number'], 3, '0', STR_PAD_LEFT) . " - " . ($raceInfo['distance_name'] ?? '') . " - " . ($raceInfo['group_name'] ?? '') . " - " . ($raceInfo['gender'] ?? 'CAMPURAN') . " | Kategori: " . ($raceInfo['class_name'] ?? 'Umum');

                $tempCsv = fopen('php://temp', 'r+');
                fputcsv($tempCsv, ['INFO', $fullRaceTitle]);
                fputcsv($tempCsv, ['BIB', 'TIME', 'HEAT', 'NAME', 'CLUB']);
                foreach ($rows as $r) {
                    $timeFmt = $r['time'] ? str_replace(':', '.', $r['time']) : '';
                    fputcsv($tempCsv, [
                        str_pad($r['bib_number'] ?? '', 3, '0', STR_PAD_LEFT),
                        $timeFmt,
                        $r['heat_name'] ?? '',
                        $r['skater_name'] ?? '',
                        $r['club_name'] ?? '-'
                    ]);
                }
                rewind($tempCsv);
                $csvContent = stream_get_contents($tempCsv);
                fclose($tempCsv);

                $zip->addFromString($safeFilename, $csvContent);
                $hasFiles = true;
            }
        }

        $zip->close();

        if (!$hasFiles) {
            die("Tidak ada data peloton/start list pada event ini.");
        }

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="Event_'.$eventId.'_CSV_Results.zip"');
        header('Content-Length: ' . filesize($zipFilename));
        readfile($zipFilename);
        unlink($zipFilename);
        exit;
    }

    public function print_result_book() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;
        if ($eventId == 0) die("Event not selected.");

        $stmtEvt = $db->prepare("SELECT * FROM roll_events WHERE id = ?");
        $stmtEvt->execute([$eventId]);
        $event = $stmtEvt->fetch(PDO::FETCH_ASSOC);

        // Tally
        $stmtTally = $db->prepare("
            SELECT c.id, c.club_name,
                SUM(CASE WHEN r.rank = 1 THEN 1 ELSE 0 END) as gold,
                SUM(CASE WHEN r.rank = 2 THEN 1 ELSE 0 END) as silver,
                SUM(CASE WHEN r.rank = 3 THEN 1 ELSE 0 END) as bronze
            FROM roll_event_results r
            JOIN roll_skaters s ON r.skater_id = s.id
            JOIN roll_clubs c ON s.club_id = c.id
            JOIN roll_event_details ed ON r.race_class_id = ed.id
            JOIN roll_entries e ON r.skater_id = e.skater_id AND r.race_class_id = e.race_class_id
            WHERE r.event_id = ? 
              AND (ed.category_name != 'EKSEBISI' OR ed.category_name IS NULL)
              AND r.rank IN (1, 2, 3) 
              AND r.status = 'OK'
            GROUP BY c.id
            ORDER BY gold DESC, silver DESC, bronze DESC, c.club_name ASC
        ");
        $stmtTally->execute([$eventId]);
        $medalTally = $stmtTally->fetchAll(PDO::FETCH_ASSOC);

        // MVP Tally
        $stmtMVP = $db->prepare("
            SELECT s.id, s.skater_name, s.gender, s.birth_date, sc.class_name as category_name, ag.group_name, c.club_name,
                SUM(CASE WHEN ranked_r.global_rank = 1 THEN 1 ELSE 0 END) as gold,
                SUM(CASE WHEN ranked_r.global_rank = 2 THEN 1 ELSE 0 END) as silver,
                SUM(CASE WHEN ranked_r.global_rank = 3 THEN 1 ELSE 0 END) as bronze
            FROM (
                SELECT r.event_id, r.race_class_id, r.skater_id, r.status, r.round,
                    (
                        SELECT COUNT(*) 
                        FROM roll_event_results r2 
                        WHERE r2.event_id = r.event_id AND r2.race_class_id = r.race_class_id 
                          AND r2.round = 'Final' AND r2.status = 'OK'
                          AND (
                              (COALESCE(LOWER(d.distance_name), '') LIKE '%eliminasi%' AND r2.rank > 0 AND (r.rank IS NULL OR r.rank = 0 OR r2.rank < r.rank OR (r2.rank = r.rank AND CAST(REPLACE(r2.heat_name, 'Heat ', '') AS UNSIGNED) < CAST(REPLACE(r.heat_name, 'Heat ', '') AS UNSIGNED))))
                              OR (COALESCE(LOWER(d.distance_name), '') LIKE '%dtt%' AND (
                                  (r2.time != '00.00.000' AND r2.time != '' AND (r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR CAST(REPLACE(REPLACE(r2.time, ':', ''), '.', '') AS UNSIGNED) < CAST(REPLACE(REPLACE(r.time, ':', ''), '.', '') AS UNSIGNED)))
                                  OR ((r2.time = r.time OR ((r2.time IS NULL OR r2.time = '' OR r2.time = '00.00.000') AND (r.time IS NULL OR r.time = '' OR r.time = '00.00.000'))) AND CAST(REPLACE(r2.heat_name, 'Heat ', '') AS UNSIGNED) < CAST(REPLACE(r.heat_name, 'Heat ', '') AS UNSIGNED))
                              ))
                              OR (
                                  COALESCE(LOWER(d.distance_name), '') NOT LIKE '%eliminasi%' AND COALESCE(LOWER(d.distance_name), '') NOT LIKE '%dtt%' AND (
                                      (COALESCE(r2.point, 0) > COALESCE(r.point, 0))
                                      OR (
                                          COALESCE(r2.point, 0) = COALESCE(r.point, 0) AND (
                                              (r2.rank > 0 AND (r.rank IS NULL OR r.rank = 0 OR r2.rank < r.rank))
                                              OR (
                                                  (COALESCE(r2.rank, 0) = COALESCE(r.rank, 0)) AND (
                                                      (r2.time != '00.00.000' AND r2.time != '' AND (r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR CAST(REPLACE(REPLACE(r2.time, ':', ''), '.', '') AS UNSIGNED) < CAST(REPLACE(REPLACE(r.time, ':', ''), '.', '') AS UNSIGNED)))
                                                      OR (
                                                          (r2.time = r.time OR ((r2.time IS NULL OR r2.time = '' OR r2.time = '00.00.000') AND (r.time IS NULL OR r.time = '' OR r.time = '00.00.000')))
                                                          AND CAST(REPLACE(r2.heat_name, 'Heat ', '') AS UNSIGNED) < CAST(REPLACE(r.heat_name, 'Heat ', '') AS UNSIGNED)
                                                      )
                                                  )
                                              )
                                          )
                                      )
                                  )
                              )
                          )
                    ) + 1 as global_rank
                FROM roll_event_results r
                JOIN roll_event_details ed ON r.race_class_id = ed.id
                LEFT JOIN roll_ref_distances d ON ed.distance_id = d.id
                WHERE r.event_id = ? AND r.round = 'Final' AND r.status = 'OK'
                  AND (ed.category_name != 'EKSEBISI' OR ed.category_name IS NULL)
                  AND LOWER(d.distance_name) NOT LIKE '%relay%'
                  AND LOWER(d.distance_name) NOT LIKE '%team%'
                  AND LOWER(d.distance_name) NOT LIKE '%pair%'
            ) ranked_r
            JOIN roll_skaters s ON ranked_r.skater_id = s.id
            LEFT JOIN roll_clubs c ON s.club_id = c.id
            JOIN roll_event_details ed ON ranked_r.race_class_id = ed.id
            LEFT JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
            JOIN roll_ref_age_groups ag ON ed.age_group_id = ag.id
            WHERE ranked_r.global_rank IN (1, 2, 3)
            GROUP BY s.id, s.skater_name, s.gender, s.birth_date, sc.class_name, ag.group_name, c.club_name
            ORDER BY sc.class_name ASC, ag.group_name ASC, s.gender ASC, 
                     gold DESC, silver DESC, bronze DESC, s.birth_date DESC, s.skater_name ASC
        ");
        $stmtMVP->execute([$eventId]);
        $mvpTally = $stmtMVP->fetchAll(PDO::FETCH_ASSOC);

        $groupedMVP = [];
        foreach ($mvpTally as $mvp) {
            $cat = $mvp['category_name'];
            $ku = $mvp['group_name'];
            $gender = ($mvp['gender'] == 'M' || $mvp['gender'] == 'L') ? 'Putra' : 'Putri';
            
            $key = "{$cat} - {$ku} - {$gender}";
            if (!isset($groupedMVP[$key])) {
                $groupedMVP[$key] = [];
            }
            $groupedMVP[$key][] = $mvp;
        }

        // Ambil SEMUA KELAS yang PUBLISHED
        $stmtClasses = $db->prepare("
            SELECT ed.*, d.distance_name, a.group_name, sc.class_name as roller_name
            FROM roll_event_details ed
            LEFT JOIN roll_ref_distances d ON ed.distance_id = d.id
            LEFT JOIN roll_ref_age_groups a ON ed.age_group_id = a.id
            LEFT JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
            WHERE ed.event_id = ? AND ed.result_status = 'Published'
            ORDER BY CAST(ed.race_number AS UNSIGNED) ASC, ed.race_number ASC, ed.gender DESC, a.id ASC
        ");
        $stmtClasses->execute([$eventId]);
        $publishedClasses = $stmtClasses->fetchAll(PDO::FETCH_ASSOC);

        $comprehensiveResults = [];

        foreach ($publishedClasses as $classInfo) {
            $pdfs = $classInfo['result_pdf'] ? json_decode($classInfo['result_pdf'], true) : [];
            if (!is_array($pdfs) && $classInfo['result_pdf']) {
                $pdfs = ['Kualifikasi' => $classInfo['result_pdf']];
            }
            
            // Hanya ambil babak Final
            $rounds = ['Final'];

            $dn = strtolower($classInfo['distance_name'] ?? '');
            $raceFormat = 'DTT';
            if (strpos($dn, 'eliminasi') !== false) {
                $raceFormat = 'ELIMINASI';
            } elseif (strpos($dn, 'ptp') !== false || strpos($dn, 'point') !== false) {
                $raceFormat = 'PTP';
            }
            $isRelay = (strpos($dn, 'relay') !== false || strpos($dn, 'pair') !== false);

            foreach ($rounds as $round) {
                // Logic urutan sama persis dengan print_result
                if ($raceFormat === 'ELIMINASI') {
                    $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN '99:99.999' ELSE r.time END ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
                } else if ($raceFormat === 'DTT') {
                    $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN 1 ELSE 0 END ASC, REPLACE(r.time, ':', '.') ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
                } else {
                    $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, r.point DESC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN 1 ELSE 0 END ASC, REPLACE(r.time, ':', '.') ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
                }

                $stmtResults = $db->prepare("
                    SELECT p.skater_id, e.bib_number, e.team_name, s.skater_name, s.gender, c.city_province as city, c.club_name, p.heat_name, p.start_grid,
                           r.rank as heat_rank, r.rank, r.point, r.time, r.status, r.is_official, r.round, r.print_round_name
                    FROM roll_pelotons p
                    JOIN roll_entries e ON p.skater_id = e.skater_id AND p.race_class_id = e.race_class_id AND p.event_id = e.event_id
                    JOIN roll_skaters s ON p.skater_id = s.id
                    LEFT JOIN roll_clubs c ON s.club_id = c.id
                    LEFT JOIN roll_event_results r ON p.event_id = r.event_id AND p.race_class_id = r.race_class_id AND p.skater_id = r.skater_id AND p.heat_name = r.heat_name AND p.round = r.round
                    WHERE p.event_id = ? AND p.race_class_id = ? AND p.round = ?
                    $orderBy
                ");
                $stmtResults->execute([$eventId, $classInfo['id'], $round]);
                $roundResults = $stmtResults->fetchAll(PDO::FETCH_ASSOC);

                if (empty($roundResults)) continue;

                $comprehensiveResults[] = [
                    'classInfo' => $classInfo,
                    'round' => $round,
                    'raceFormat' => $raceFormat,
                    'isRelay' => $isRelay,
                    'results' => $roundResults
                ];
            }
        }

        // Render view langsung tanpa template admin (topbar/sidebar)
        require_once __DIR__ . '/../../../../views/roll/admin/export/pdf_result.php';
        exit;
    }

    public function print_race_book() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;
        if ($eventId == 0) die("Event not selected.");

        $stmtEvt = $db->prepare("SELECT * FROM roll_events WHERE id = ?");
        $stmtEvt->execute([$eventId]);
        $event = $stmtEvt->fetch(PDO::FETCH_ASSOC);

        // Pelotons
        $stmtP = $db->prepare("
            SELECT p.*, s.skater_name, e.bib_number, c.club_name, d.distance_name, a.group_name, ed.category_name, ed.race_number
            FROM roll_pelotons p
            JOIN roll_skaters s ON p.skater_id = s.id
            JOIN roll_entries e ON p.skater_id = e.skater_id AND p.race_class_id = e.race_class_id AND p.event_id = e.event_id
            LEFT JOIN roll_clubs c ON s.club_id = c.id
            JOIN roll_event_details ed ON p.race_class_id = ed.id
            LEFT JOIN roll_ref_distances d ON ed.distance_id = d.id
            LEFT JOIN roll_ref_age_groups a ON ed.age_group_id = a.id
            WHERE p.event_id = ?
            ORDER BY CAST(ed.race_number AS UNSIGNED) ASC, a.min_year ASC, d.distance_name ASC, p.heat_name ASC, p.start_grid ASC
        ");
        $stmtP->execute([$eventId]);
        $pelotonsData = $stmtP->fetchAll(PDO::FETCH_ASSOC);

        // Group by Class, then Heat
        $classes = [];
        foreach ($pelotonsData as $row) {
            $classKey = $row['group_name'] . ' - ' . $row['distance_name'] . ' (' . $row['category_name'] . ')';
            $classes[$classKey]['distance'] = $row['distance_name'];
            $classes[$classKey]['format'] = $row['distance_name']; 
            $classes[$classKey]['heats'][$row['heat_name']][] = $row;
        }

        return $this->view('roll/admin/export/pdf_racebook', [
            'event' => $event,
            'classes' => $classes
        ]);
    }

    public function export_meal_vouchers() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;

        if ($eventId == 0) {
            die("Event not selected.");
        }

        // Get Event Info
        $stmtEvt = $db->prepare("SELECT event_name FROM roll_events WHERE id = ?");
        $stmtEvt->execute([$eventId]);
        $eventName = $stmtEvt->fetchColumn() ?: 'Event';

        // Get all entered skaters with their race numbers
        // A skater could have multiple races on the same day, so we group by Day and skater
        $sql = "
            SELECT 
                s.skater_name, 
                e.bib_number, 
                c.club_name,
                ed.race_number
            FROM roll_entries e
            JOIN roll_skaters s ON e.skater_id = s.id
            LEFT JOIN roll_clubs c ON s.club_id = c.id
            JOIN roll_event_details ed ON e.race_class_id = ed.id
            WHERE e.event_id = ?
            ORDER BY c.club_name ASC, s.skater_name ASC
        ";
        $stmt = $db->prepare($sql);
        $stmt->execute([$eventId]);
        $rawData = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $vouchersByDay = [];
        
        foreach ($rawData as $row) {
            $rn = $row['race_number'];
            if (!$rn) continue;
            
            // Extract day from first digit of race number
            $dayDigit = (int)substr($rn, 0, 1);
            if ($dayDigit === 0) $dayDigit = 1;

            $skaterKey = $row['bib_number'] . '_' . $row['skater_name'];

            if (!isset($vouchersByDay[$dayDigit])) {
                $vouchersByDay[$dayDigit] = [];
            }

            // Ensure unique skater per day
            if (!isset($vouchersByDay[$dayDigit][$skaterKey])) {
                $vouchersByDay[$dayDigit][$skaterKey] = [
                    'skater_name' => $row['skater_name'],
                    'bib_number'  => $row['bib_number'],
                    'club_name'   => $row['club_name']
                ];
            }
        }

        ksort($vouchersByDay);

        // Generate XML Spreadsheet 2003
        $filename = "Voucher_Makan_" . preg_replace('/[^a-zA-Z0-9_-]/', '_', $eventName) . ".xls";

        header("Content-Type: application/vnd.ms-excel; charset=utf-8");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Pragma: no-cache");
        header("Expires: 0");

        echo '<?xml version="1.0"?>' . "\n";
        echo '<?mso-application progid="Excel.Sheet"?>' . "\n";
        echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
        echo ' xmlns:o="urn:schemas-microsoft-com:office:office"' . "\n";
        echo ' xmlns:x="urn:schemas-microsoft-com:office:excel"' . "\n";
        echo ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
        echo ' xmlns:html="http://www.w3.org/TR/REC-html40">' . "\n";

        // Styles
        echo ' <Styles>' . "\n";
        echo '  <Style ss:ID="Default" ss:Name="Normal">' . "\n";
        echo '   <Alignment ss:Vertical="Bottom"/>' . "\n";
        echo '   <Borders/>' . "\n";
        echo '   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>' . "\n";
        echo '   <Interior/>' . "\n";
        echo '   <NumberFormat/>' . "\n";
        echo '   <Protection/>' . "\n";
        echo '  </Style>' . "\n";
        echo '  <Style ss:ID="sHeader">' . "\n";
        echo '   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#FFFFFF" ss:Bold="1"/>' . "\n";
        echo '   <Interior ss:Color="#4F81BD" ss:Pattern="Solid"/>' . "\n";
        echo '  </Style>' . "\n";
        echo ' </Styles>' . "\n";

        foreach ($vouchersByDay as $day => $skaters) {
            echo ' <Worksheet ss:Name="Hari ' . $day . '">' . "\n";
            echo '  <Table>' . "\n";
            
            // Header Row
            echo '   <Row>' . "\n";
            echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">No.</Data></Cell>' . "\n";
            echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">BIB</Data></Cell>' . "\n";
            echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Nama Atlet</Data></Cell>' . "\n";
            echo '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Klub</Data></Cell>' . "\n";
            echo '   </Row>' . "\n";

            // Data Rows
            $no = 1;
            foreach ($skaters as $skater) {
                echo '   <Row>' . "\n";
                echo '    <Cell><Data ss:Type="Number">' . $no++ . '</Data></Cell>' . "\n";
                echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($skater['bib_number'] ?? '') . '</Data></Cell>' . "\n";
                echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($skater['skater_name'] ?? '') . '</Data></Cell>' . "\n";
                echo '    <Cell><Data ss:Type="String">' . htmlspecialchars($skater['club_name'] ?? '') . '</Data></Cell>' . "\n";
                echo '   </Row>' . "\n";
            }

            echo '  </Table>' . "\n";
            echo ' </Worksheet>' . "\n";
        }

        echo '</Workbook>';
        exit;
    }

    public function print_athlete_book() {
        $db = \App\Core\Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;

        if ($eventId == 0) {
            die("Event not selected.");
        }

        // Get Event Info
        $stmtEvent = $db->prepare("SELECT * FROM roll_events WHERE id = ?");
        $stmtEvent->execute([$eventId]);
        $event = $stmtEvent->fetch(\PDO::FETCH_ASSOC);

        // Get Athletes Grouped by Club, ignoring relay classes
        $stmtAthletes = $db->prepare("
            SELECT DISTINCT
                s.id as skater_id,
                s.skater_name,
                s.gender,
                s.birth_date,
                e.bib_number,
                c.club_name,
                c.id as club_id,
                a.group_name as ku
            FROM roll_entries e
            JOIN roll_skaters s ON e.skater_id = s.id
            JOIN roll_clubs c ON e.club_id = c.id
            JOIN roll_event_details ed ON e.race_class_id = ed.id
            JOIN roll_ref_distances d ON ed.distance_id = d.id
            JOIN roll_ref_age_groups a ON ed.age_group_id = a.id
            LEFT JOIN roll_payments pay_club ON pay_club.club_id = e.club_id AND pay_club.event_id = e.event_id
            LEFT JOIN roll_manual_payments pay_man ON pay_man.invoice_code = e.manual_invoice_code
            WHERE e.event_id = ?
              AND (pay_club.status = 'Paid' OR pay_man.status = 'Paid')
              AND LOWER(d.distance_name) NOT LIKE '%relay%'
              AND LOWER(d.distance_name) NOT LIKE '%team%'
              AND LOWER(d.distance_name) NOT LIKE '%pair%'
            ORDER BY c.club_name ASC, a.group_name ASC, s.skater_name ASC
        ");
        $stmtAthletes->execute([$eventId]);
        $athletes = $stmtAthletes->fetchAll(\PDO::FETCH_ASSOC);

        $clubsData = [];
        foreach ($athletes as $ath) {
            $clubsData[$ath['club_name']][] = $ath;
        }

        require_once __DIR__ . '/../../../../views/roll/admin/export/athlete_book_pdf.php';
        exit;
    }

    public function export_winners_csv() {
        $db = Database::getInstance()->getConnection();
        $eventId = $_SESSION['roll_admin_active_event_id'] ?? 0;
        if ($eventId == 0) {
            die("Event not selected.");
        }

        $limitRank = $_GET['limit_rank'] ?? 'TOP3'; // TOP3, TOP5, ALL
        $filterCategory = $_GET['category'] ?? 'ALL'; // ALL or specific category
        $filterStatus = $_GET['status'] ?? 'all'; // all or published

        $stmtEvt = $db->prepare("SELECT * FROM roll_events WHERE id = ?");
        $stmtEvt->execute([$eventId]);
        $event = $stmtEvt->fetch(PDO::FETCH_ASSOC);
        $eventName = $event['event_name'] ?? ('Event_' . $eventId);

        $whereClass = "WHERE ed.event_id = ?";
        $paramsClass = [$eventId];

        if ($filterStatus === 'published') {
            $whereClass .= " AND ed.result_status = 'Published'";
        }

        if ($filterCategory !== 'ALL' && !empty($filterCategory)) {
            $whereClass .= " AND sc.class_name = ?";
            $paramsClass[] = $filterCategory;
        }

        $stmtClasses = $db->prepare("
            SELECT ed.id, ed.race_number, ed.gender, ed.category_name, ed.custom_name,
                   d.distance_name, a.group_name, sc.class_name as skate_class_name
            FROM roll_event_details ed
            LEFT JOIN roll_ref_distances d ON ed.distance_id = d.id
            LEFT JOIN roll_ref_age_groups a ON ed.age_group_id = a.id
            LEFT JOIN roll_ref_skate_classes sc ON ed.skate_class_id = sc.id
            $whereClass
            ORDER BY CAST(ed.race_number AS UNSIGNED) ASC, ed.race_number ASC, ed.gender DESC, a.id ASC
        ");
        $stmtClasses->execute($paramsClass);
        $classes = $stmtClasses->fetchAll(PDO::FETCH_ASSOC);

        $stmtRounds = $db->prepare("
            SELECT DISTINCT round 
            FROM roll_pelotons 
            WHERE event_id = ? AND race_class_id = ? 
            ORDER BY CASE round 
                WHEN 'Kualifikasi' THEN 1 
                WHEN 'Perempat Final' THEN 2 
                WHEN 'Semi Final' THEN 3 
                WHEN 'Final' THEN 4 
                ELSE 5 END
        ");

        $stmtResRounds = $db->prepare("
            SELECT DISTINCT round 
            FROM roll_event_results 
            WHERE event_id = ? AND race_class_id = ? 
            ORDER BY CASE round 
                WHEN 'Kualifikasi' THEN 1 
                WHEN 'Perempat Final' THEN 2 
                WHEN 'Semi Final' THEN 3 
                WHEN 'Final' THEN 4 
                ELSE 5 END
        ");

        $cleanEvent = preg_replace('/[^a-zA-Z0-9_-]/', '_', $eventName);
        $filename = "Rekap_Pemenang_{$cleanEvent}_" . date('Ymd_His') . ".csv";

        while (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        // UTF-8 BOM for Excel
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

        fputcsv($output, [
            'No_Lomba',
            'Nama_Lomba',
            'Kategori',
            'Kelompok_Umur',
            'Gender',
            'Jarak',
            'Babak',
            'Peringkat',
            'Juara',
            'Medali',
            'BIB',
            'Nama_Atlet',
            'Klub',
            'Kota_Provinsi',
            'Waktu',
            'Poin',
            'Status'
        ]);

        foreach ($classes as $classInfo) {
            $classId = $classInfo['id'];

            // Tentukan babak penentu
            $stmtRounds->execute([$eventId, $classId]);
            $rounds = $stmtRounds->fetchAll(PDO::FETCH_COLUMN);

            if (empty($rounds)) {
                $stmtResRounds->execute([$eventId, $classId]);
                $rounds = $stmtResRounds->fetchAll(PDO::FETCH_COLUMN);
            }

            if (empty($rounds)) {
                continue;
            }

            if (in_array('Final', $rounds)) {
                $targetRound = 'Final';
            } else {
                $targetRound = end($rounds);
            }

            $dn = strtolower($classInfo['distance_name'] ?? '');
            $raceFormat = 'DTT';
            if (strpos($dn, 'eliminasi') !== false) {
                $raceFormat = 'ELIMINASI';
            } elseif (strpos($dn, 'ptp') !== false || strpos($dn, 'point') !== false) {
                $raceFormat = 'PTP';
            }
            $isRelay = (strpos($dn, 'relay') !== false || strpos($dn, 'pair') !== false);

            if ($raceFormat === 'ELIMINASI') {
                $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN '99:99.999' ELSE r.time END ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
            } else if ($raceFormat === 'DTT') {
                $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN 1 ELSE 0 END ASC, REPLACE(r.time, ':', '.') ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
            } else {
                $orderBy = "ORDER BY CASE WHEN COALESCE(r.status, 'OK') = 'OK' THEN 0 ELSE 1 END ASC, CASE WHEN r.rank IS NULL OR CAST(r.rank AS CHAR) = '0' OR CAST(r.rank AS CHAR) = '' THEN 1 ELSE 0 END ASC, r.rank ASC, r.point DESC, CASE WHEN r.time IS NULL OR r.time = '' OR r.time = '00.00.000' OR r.time = '00:00.000' THEN 1 ELSE 0 END ASC, REPLACE(r.time, ':', '.') ASC, CAST(REPLACE(p.heat_name, 'Heat ', '') AS UNSIGNED) ASC, p.start_grid ASC";
            }

            $stmtResults = $db->prepare("
                SELECT p.skater_id, e.bib_number, e.team_name, s.skater_name, s.gender, c.city_province as city, c.club_name, p.heat_name, p.start_grid,
                       r.rank as heat_rank, r.rank, r.point, r.time, r.status, r.is_official, r.round, r.print_round_name
                FROM roll_pelotons p
                JOIN roll_entries e ON p.skater_id = e.skater_id AND p.race_class_id = e.race_class_id AND p.event_id = e.event_id
                JOIN roll_skaters s ON p.skater_id = s.id
                LEFT JOIN roll_clubs c ON s.club_id = c.id
                LEFT JOIN roll_event_results r ON p.event_id = r.event_id AND p.race_class_id = r.race_class_id AND p.skater_id = r.skater_id AND p.heat_name = r.heat_name AND p.round = r.round
                WHERE p.event_id = ? AND p.race_class_id = ? AND p.round = ?
                $orderBy
            ");
            $stmtResults->execute([$eventId, $classId, $targetRound]);
            $roundResults = $stmtResults->fetchAll(PDO::FETCH_ASSOC);

            if (empty($roundResults)) {
                continue;
            }

            if ($isRelay) {
                $grouped = [];
                foreach ($roundResults as $r) {
                    $teamKey = $r['heat_name'] . '_' . ($r['team_name'] ?: $r['club_name'] ?: $r['bib_number']);
                    if (!isset($grouped[$teamKey])) {
                        $grouped[$teamKey] = $r;
                        $grouped[$teamKey]['members'] = [];
                    }
                    $grouped[$teamKey]['members'][] = [
                        'name' => $r['skater_name'],
                        'bib' => $r['bib_number']
                    ];
                }
                $finalList = array_values($grouped);
            } else {
                $finalList = $roundResults;
            }

            // Susun label lomba
            $genderRaw = $classInfo['gender'] ?? '';
            $genderLabel = ($genderRaw === 'M' || $genderRaw === 'L' || strtolower($genderRaw) === 'putra') ? 'PUTRA' : 'PUTRI';
            $raceNumber = str_pad($classInfo['race_number'], 3, '0', STR_PAD_LEFT);
            $raceName = trim(($classInfo['skate_class_name'] ?? '') . ' ' . ($classInfo['group_name'] ?? '') . ' ' . $genderLabel . ' ' . ($classInfo['distance_name'] ?? ''));
            if (!empty($classInfo['custom_name'])) {
                $raceName = $classInfo['custom_name'] . ' (' . $raceName . ')';
            }

            $globalRank = 0;
            foreach ($finalList as $res) {
                $statusStr = strtoupper($res['status'] ?? 'OK');
                $isOk = ($statusStr === 'OK' || empty($res['status']));

                if ($isOk) {
                    $globalRank++;
                }

                // Cek batasan ranking
                if ($limitRank === 'TOP3' && (!$isOk || $globalRank > 3)) {
                    if (!$isOk) continue;
                    break;
                }
                if ($limitRank === 'TOP5' && (!$isOk || $globalRank > 5)) {
                    if (!$isOk) continue;
                    break;
                }

                $displayRank = $isOk ? $globalRank : '-';
                $juaraLabel = $isOk ? ('Juara ' . $globalRank) : $statusStr;
                
                $medaliLabel = '-';
                if ($isOk) {
                    if ($globalRank === 1) $medaliLabel = 'EMAS';
                    elseif ($globalRank === 2) $medaliLabel = 'PERAK';
                    elseif ($globalRank === 3) $medaliLabel = 'PERUNGGU';
                }

                if ($isRelay) {
                    $bibStr = implode(', ', array_filter(array_column($res['members'] ?? [], 'bib')));
                    $skaterNameStr = implode(', ', array_filter(array_column($res['members'] ?? [], 'name')));
                    if (empty($skaterNameStr)) {
                        $skaterNameStr = $res['skater_name'] ?? '-';
                    }
                    $clubNameStr = $res['team_name'] ?: ($res['club_name'] ?? '-');
                } else {
                    $bibStr = $res['bib_number'] ?? '-';
                    $skaterNameStr = $res['skater_name'] ?? '-';
                    $clubNameStr = $res['team_name'] ?: ($res['club_name'] ?? '-');
                }

                $cityStr = $res['city'] ?? '-';
                $timeStr = (!empty($res['time']) && $res['time'] !== '00.00.000') ? $res['time'] : '-';
                $pointStr = (isset($res['point']) && $res['point'] !== null && $res['point'] !== '') ? $res['point'] : '-';

                fputcsv($output, [
                    $raceNumber,
                    $raceName,
                    strtoupper($classInfo['skate_class_name'] ?? '-'),
                    strtoupper($classInfo['group_name'] ?? '-'),
                    $genderLabel,
                    strtoupper($classInfo['distance_name'] ?? '-'),
                    strtoupper($targetRound),
                    $displayRank,
                    $juaraLabel,
                    $medaliLabel,
                    $bibStr,
                    strtoupper($skaterNameStr),
                    strtoupper($clubNameStr),
                    strtoupper($cityStr),
                    $timeStr,
                    $pointStr,
                    $statusStr
                ]);
            }
        }

        fclose($output);
        exit;
    }
}
