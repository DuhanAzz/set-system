<!-- HEADER -->
<div class="max-w-7xl mx-auto mb-6 flex flex-col lg:flex-row justify-between items-start gap-6 print:hidden">
    <div>
        <h1 class="text-4xl font-black uppercase tracking-tighter italic text-slate-900 leading-none">Global Race Book</h1>
        <p class="text-sm text-slate-500 font-bold uppercase tracking-widest mt-2">
            Pusat Kendali Cetak Buku & Auto-Seeding
        </p>
    </div>
</div>

<div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
    <div class="bg-white rounded-2xl border border-slate-200 p-6 flex items-center gap-5 shadow-sm">
        <div class="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center text-2xl shrink-0">👟</div>
        <div>
            <p class="text-3xl font-black text-slate-900"><?= number_format($totalPaidAthletes) ?></p>
            <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Atlet Lunas</p>
        </div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-200 p-6 flex items-center gap-5 shadow-sm">
        <div class="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center text-2xl shrink-0">🏁</div>
        <div>
            <p class="text-3xl font-black text-slate-900"><?= number_format($totalClasses) ?></p>
            <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Kelas Lomba Siap Di-generate</p>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto">
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-8">
        
        <?php if($totalPaidAthletes == 0): ?>
            <div class="py-10 opacity-50 text-center">
                <div class="text-5xl mb-4 grayscale">⚠️</div>
                <h3 class="font-black text-slate-400 uppercase tracking-widest text-lg">Belum Ada Atlet Terdaftar</h3>
                <p class="text-sm text-slate-400 mt-2">Pastikan peserta sudah mendaftar dan pembayaran telah diverifikasi.</p>
            </div>
        <?php else: ?>
            
            <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-6 border-b border-slate-100 pb-6">
                <div>
                    <h2 class="text-2xl font-black uppercase tracking-widest text-slate-800">Cetak Full Race Book</h2>
                    <p class="text-slate-500 font-bold uppercase text-[10px] mt-1">
                        Pilih konfigurasi halaman dan informasi yang ingin ditampilkan.
                    </p>
                </div>
                
                <?php if($hasGenerated): ?>
                    <div class="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-4 py-2 rounded-full border border-emerald-200 text-xs font-bold uppercase tracking-widest">
                        <span>✅</span> Race Book Sudah Di-generate
                    </div>
                <?php endif; ?>
            </div>

            <form method="POST" action="<?= getenv('APP_URL') ?>/roll/admin/pelotons/printFull" target="_blank" enctype="multipart/form-data" class="space-y-8">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Header Options -->
                    <div>
                        <h3 class="text-sm font-black uppercase tracking-widest bg-slate-100 p-3 rounded-lg mb-4 text-slate-700">Pengaturan Header</h3>
                        <div class="space-y-3">
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="cfg_event_name" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Tampilkan Nama Event</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="cfg_date" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Tampilkan Tanggal Event</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="cfg_group" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Tampilkan Kelompok Umur</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="cfg_gender" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Tampilkan Gender</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="cfg_distance" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Tampilkan Jarak Lomba</span>
                            </label>
                        </div>
                    </div>

                    <!-- Column Options -->
                    <div>
                        <h3 class="text-sm font-black uppercase tracking-widest bg-slate-100 p-3 rounded-lg mb-4 text-slate-700">Pengaturan Kolom Tabel</h3>
                        <div class="space-y-3">
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="col_lane" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Lane / Urut (Start Grid)</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="col_bib" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">No. BIB</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="col_nama" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Nama Atlet</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="col_klub" checked class="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-sm font-bold text-slate-700">Klub / Kontingen</span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-sm font-black uppercase tracking-widest bg-slate-100 p-3 rounded-lg mb-4 text-slate-700">Tambahan Halaman</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-2">Upload Custom Cover (Opsional)</label>
                            <input type="file" name="cover_image" accept="image/*" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                        </div>
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <label class="block text-sm font-bold text-slate-700">Upload Gambar Jadwal (Opsional)</label>
                                <button type="button" onclick="quickGenerateTime(this)" class="inline-flex items-center gap-1 bg-amber-100 hover:bg-amber-200 text-amber-700 text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-md transition-colors" title="Generate Waktu Perlombaan Otomatis">
                                    <span>⚡</span> Generate Waktu
                                </button>
                            </div>
                            <input type="file" name="schedule_image" accept="image/*" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                            <label class="flex items-center gap-2 mt-3 cursor-pointer">
                                <input type="checkbox" name="show_schedule_auto" checked class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-xs font-bold text-slate-600">Gunakan Tabel Rekap Jadwal Otomatis (Jika tidak upload gambar)</span>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="flex flex-col sm:flex-row justify-end items-center gap-4 pt-6 border-t border-slate-100">
                    <!-- TOMBOL DOWNLOAD PDF -->
                    <button type="submit" <?= !$hasGenerated ? 'disabled' : '' ?> class="<?= $hasGenerated ? 'bg-indigo-600 hover:bg-indigo-700 shadow-lg hover:-translate-y-1' : 'bg-slate-200 text-slate-400 cursor-not-allowed pointer-events-none' ?> text-white font-black uppercase tracking-widest text-sm py-4 px-8 rounded-xl transition-all flex items-center gap-3">
                        <span class="text-xl">🖨️</span>
                        <span>Generate & Print PDF</span>
                    </button>
                </div>
                
                <?php if(!$hasGenerated): ?>
                    <p class="text-[10px] text-right text-red-500 mt-2 font-bold uppercase tracking-widest">
                        ⚠️ Generate Ulang Auto-Seeding (di bawah) terlebih dahulu untuk mengaktifkan tombol Cetak PDF
                    </p>
                <?php endif; ?>

            </form>
        <?php endif; ?>
    </div>
</div>

<?php if($eventId > 0 && !empty($groupedClasses)): ?>
<!-- ========================================== -->
<!-- BAGIAN GENERATE SERI PER KATEGORI -->
<!-- ========================================== -->
<div class="max-w-4xl mx-auto my-10 bg-white p-8 rounded-2xl shadow-xl print-hidden border border-slate-200">
    <div class="flex items-center justify-between border-b pb-4 mb-6">
        <div>
            <h2 class="text-xl font-black uppercase tracking-widest text-slate-800 flex items-center gap-2">
                <span>⚙️</span> Daftar Kelas & Generate Heat
            </h2>
            <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Dikelompokkan berdasarkan kategori (Speed, Standard, Pemula)</p>
        </div>
        
        <div class="flex items-center gap-2">
            <button type="button" onclick="document.getElementById('modalMerge').classList.remove('hidden')" class="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold uppercase tracking-widest text-[11px] py-3 px-5 rounded-xl border border-indigo-200 transition-all shadow-sm flex items-center gap-2">
                <span class="text-sm">🔗</span>
                <span>Gabung Nomor Lomba</span>
            </button>
            <form id="formGenerateAuto" method="POST" action="<?= getenv('APP_URL') ?>/roll/admin/pelotons/generateAll" onsubmit="return confirm('⚡ GENERATE RACE BOOK\n\nProses ini akan menyusun daftar peserta untuk seluruh <?= $totalClasses ?> kelas lomba.\n\n• Kelas HEAT → Babak Kualifikasi (Acak Terdistribusi)\n• Kelas STARTING LIST → Daftar langsung final\n\n<?= $hasGenerated ? '⚠️ Data seeding sebelumnya akan DITIMPA!\n\n' : '' ?>Lanjutkan?')">
                <input type="hidden" name="round" value="Kualifikasi">
                <input type="hidden" name="algorithm" value="distributed">
                <input type="hidden" name="max_lanes" value="0">
                <button type="submit" class="bg-slate-800 hover:bg-slate-900 text-white font-bold uppercase tracking-widest text-[11px] py-3 px-5 rounded-xl transition-all shadow-md flex items-center gap-2">
                    <span class="text-sm">⚡</span>
                    <span>Generate Seluruh Heat</span>
                </button>
            </form>
        </div>
    </div>

    <div class="space-y-6">
        <?php foreach($groupedClasses as $category => $classes): ?>
            <div>
                <h3 class="text-sm font-black text-indigo-700 uppercase tracking-widest bg-indigo-50 px-4 py-2 rounded-lg mb-3 inline-block">
                    <?= htmlspecialchars($category) ?> (<?= count($classes) ?> Kelas)
                </h3>
                
                <div class="space-y-3 pl-2">
                    <?php foreach($classes as $rn => $clsGroup): 
                        $raceNum = str_pad($rn, 3, '0', STR_PAD_LEFT);
                        $genderLabel = implode(' & ', $clsGroup['genders']);
                        
                        // Deteksi default mekanisme
                        // Jika kategori mengandung kata 'Pemula', maka paksa jadi starting_list
                        if (stripos($clsGroup['category_name'], 'Pemula') !== false) {
                            $defaultMech = 'starting_list';
                        } else {
                            $defaultMech = \App\Roll\Controllers\Admin\RollPelotonController::getMechanism($clsGroup['distance_name'])['mechanism'];
                        }
                        
                        $classIdsJson = htmlspecialchars(json_encode($clsGroup['classes']));
                    ?>
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors">
                            <div class="flex items-center gap-3">
                                <div class="<?= !empty($clsGroup['is_eksebisi']) ? 'bg-red-600' : 'bg-indigo-600' ?> text-white font-black text-sm px-3 py-1.5 rounded-lg shadow-sm">R<?= htmlspecialchars(str_pad($clsGroup['race_number'], 3, '0', STR_PAD_LEFT)) ?></div>
                                <div>
                                    <div class="text-sm font-black text-slate-800 uppercase tracking-widest">
                                        <?= htmlspecialchars($clsGroup['distance_name']) ?> - <?= htmlspecialchars($clsGroup['group_name']) ?> <?= $genderLabel ?>
                                        <?php if (!empty($clsGroup['is_eksebisi'])): ?>
                                            <span class="ml-2 bg-red-100 text-red-600 px-2 py-0.5 rounded font-black text-[9px] uppercase tracking-widest border border-red-200">Eksebisi</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5 flex items-center gap-2">
                                        <span class="bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded">
                                            Total: <?= (int)$clsGroup['total_entries'] ?> Atlet 
                                            <?php if((int)$clsGroup['total_pa'] > 0 || (int)$clsGroup['total_pi'] > 0): ?>
                                                (Pa: <?= (int)$clsGroup['total_pa'] ?>, Pi: <?= (int)$clsGroup['total_pi'] ?>)
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <form class="flex items-center gap-2 form-generate-single" data-class-ids="<?= $classIdsJson ?>">
                                <div class="flex flex-col gap-1">
                                    <select name="override_mechanism" class="mech-select border-slate-300 rounded-lg text-xs font-bold text-slate-700 py-1.5 pl-2 pr-6 focus:ring-indigo-500">
                                        <option value="heat" <?= $defaultMech === 'heat' ? 'selected' : '' ?>>🔥 Heat</option>
                                        <option value="starting_list" <?= $defaultMech === 'starting_list' ? 'selected' : '' ?>>📋 Starting List</option>
                                    </select>
                                </div>
                                <div class="flex flex-col gap-1 w-16 input-max-lanes <?= $defaultMech === 'starting_list' ? 'hidden' : '' ?>">
                                    <input type="number" name="max_lanes" value="<?= (int)$clsGroup['max_lanes'] ?>" min="1" max="50" class="border-slate-300 rounded-lg text-xs font-bold text-slate-700 py-1.5 px-2 text-center focus:ring-indigo-500" title="Max Peserta per Heat">
                                </div>
                                <button type="submit" class="btn-generate-single bg-indigo-100 hover:bg-indigo-200 text-indigo-700 p-2 rounded-lg transition-colors flex items-center gap-1" title="Generate Heat Kelas Ini">
                                    <span class="text-sm">⚡</span>
                                    <span class="text-xs font-bold uppercase tracking-widest hidden sm:inline">Gen</span>
                                </button>
                                <?php if (count($clsGroup['classes']) == 1): ?>
                                    <a href="<?= getenv('APP_URL') ?>/roll/admin/pelotons/detail?class_id=<?= $clsGroup['classes'][0] ?>" target="_blank" class="bg-emerald-100 hover:bg-emerald-200 text-emerald-700 p-2 rounded-lg transition-colors flex items-center gap-1" title="Lihat Detail Seri">
                                        <span class="text-sm">👁️</span>
                                        <span class="text-xs font-bold uppercase tracking-widest hidden sm:inline">View</span>
                                    </a>
                                <?php else: ?>
                                    <div class="flex items-center gap-1">
                                    <?php foreach($clsGroup['classes'] as $idx => $cId): 
                                        $label = ($idx == 0) ? 'Pa' : 'Pi';
                                    ?>
                                        <a href="<?= getenv('APP_URL') ?>/roll/admin/pelotons/detail?class_id=<?= $cId ?>" target="_blank" class="bg-emerald-100 hover:bg-emerald-200 text-emerald-700 p-2 rounded-lg transition-colors flex items-center gap-1" title="Lihat Detail <?= $label ?>">
                                            <span class="text-sm">👁️</span>
                                            <span class="text-[10px] font-bold uppercase tracking-widest hidden sm:inline"><?= $label ?></span>
                                        </a>
                                    <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle Max Lanes input visibility
    document.querySelectorAll('.mech-select').forEach(select => {
        select.addEventListener('change', function() {
            const form = this.closest('form');
            const maxLanesContainer = form.querySelector('.input-max-lanes');
            if(this.value === 'heat') {
                maxLanesContainer.classList.remove('hidden');
            } else {
                maxLanesContainer.classList.add('hidden');
            }
        });
    });

    // Save and Restore Checkbox state for Print Configuration
    const printCheckboxes = document.querySelectorAll('input[type="checkbox"][name^="cfg_"], input[type="checkbox"][name^="col_"], input[type="checkbox"][name="show_schedule_auto"]');
    printCheckboxes.forEach(cb => {
        // Restore from localStorage
        const saved = localStorage.getItem('roll_print_config_' + cb.name);
        if (saved !== null) {
            cb.checked = (saved === 'true');
        }
        // Save on change
        cb.addEventListener('change', function() {
            localStorage.setItem('roll_print_config_' + this.name, this.checked);
        });
    });

    // Handle AJAX form submission for single class generation and State Preservation
    document.querySelectorAll('.form-generate-single').forEach(form => {
        const classIds = form.getAttribute('data-class-ids');
        const mechSelect = form.querySelector('.mech-select');
        const lanesInput = form.querySelector('input[name="max_lanes"]');
        
        // Restore state
        const savedMech = localStorage.getItem('roll_mech_' + classIds);
        if (savedMech) {
            mechSelect.value = savedMech;
            // Trigger change to update UI (hide/show lanes)
            mechSelect.dispatchEvent(new Event('change'));
        }
        
        const savedLanes = localStorage.getItem('roll_lanes_' + classIds);
        if (savedLanes) {
            lanesInput.value = savedLanes;
        }
        
        // Save state on change
        if (mechSelect) {
            mechSelect.addEventListener('change', function() {
                localStorage.setItem('roll_mech_' + classIds, this.value);
            });
        }
        if (lanesInput) {
            lanesInput.addEventListener('change', function() {
                localStorage.setItem('roll_lanes_' + classIds, this.value);
            });
        }
    });

    // Intercept formGenerateAuto to save all current states before submitting
    const formAuto = document.getElementById('formGenerateAuto');
    if (formAuto) {
        formAuto.addEventListener('submit', function() {
            document.querySelectorAll('.form-generate-single').forEach(form => {
                const classIds = form.getAttribute('data-class-ids');
                const mechSelect = form.querySelector('.mech-select');
                const lanesInput = form.querySelector('input[name="max_lanes"]');
                if (mechSelect) localStorage.setItem('roll_mech_' + classIds, mechSelect.value);
                if (lanesInput) localStorage.setItem('roll_lanes_' + classIds, lanesInput.value);
            });
        });
    }

    // Handle AJAX form submission for single class generation and State Preservation
    document.querySelectorAll('.form-generate-single').forEach(form => {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const classIds = JSON.parse(this.dataset.classIds || '[]');
            const mechanism = this.querySelector('[name="override_mechanism"]').value;
            const maxLanes = this.querySelector('[name="max_lanes"]').value;
            
            const btn = this.querySelector('.btn-generate-single');
            const originalHtml = btn.innerHTML;
            
            btn.innerHTML = '<span class="text-xs font-bold">⏳</span>';
            btn.disabled = true;
            
            try {
                // Eksekusi semua class_id sekaligus menggunakan Promise.all
                const promises = classIds.map(classId => 
                    fetch(`<?= getenv('APP_URL') ?>/roll/admin/pelotons/process?class_id=${classId}&round=Kualifikasi&algorithm=distributed&max_lanes=${maxLanes}&override_mechanism=${mechanism}`)
                    .then(res => res.json())
                );
                
                const results = await Promise.all(promises);
                const allSuccess = results.every(data => data.success);
                
                if (allSuccess) {
                    btn.classList.remove('bg-indigo-100', 'text-indigo-700');
                    btn.classList.add('bg-emerald-500', 'text-white');
                    btn.innerHTML = '<span class="text-xs font-bold">✅</span>';
                    setTimeout(() => {
                        btn.innerHTML = originalHtml;
                        btn.classList.add('bg-indigo-100', 'text-indigo-700');
                        btn.classList.remove('bg-emerald-500', 'text-white');
                        btn.disabled = false;
                    }, 2000);
                } else {
                    const errorMessages = results.filter(d => !d.success).map(d => d.message).join(', ');
                    alert('Gagal: ' + errorMessages);
                    btn.innerHTML = originalHtml;
                    btn.disabled = false;
                }
            } catch (err) {
                console.error(err);
                alert('Terjadi kesalahan jaringan saat memproses.');
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            }
        });
    });

    // ----------------------------------------------------------------------
    // STATE PERSISTENCE (Menyimpan form ke localStorage agar tidak reset)
    // ----------------------------------------------------------------------
    const STORAGE_KEY = 'global_racebook_state';
    let savedState = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');

    // Restore state
    // 1. Checkboxes for Print PDF
    document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        if(savedState[cb.name] !== undefined) {
            cb.checked = savedState[cb.name];
        }
        cb.addEventListener('change', () => {
            savedState[cb.name] = cb.checked;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(savedState));
        });
    });

    // 2. Select and Input for Class Generation
    document.querySelectorAll('.form-generate-single').forEach((form, index) => {
        const mechSelect = form.querySelector('[name="override_mechanism"]');
        const maxLanesInput = form.querySelector('[name="max_lanes"]');
        
        // Buat ID unik berdasarkan raceNum / dataset
        const uniqueId = form.dataset.classIds; 
        
        if (savedState['mech_' + uniqueId]) {
            mechSelect.value = savedState['mech_' + uniqueId];
            // Trigger change untuk toggle visibility maxLanes
            mechSelect.dispatchEvent(new Event('change'));
        }
        
        if (savedState['maxlanes_' + uniqueId]) {
            maxLanesInput.value = savedState['maxlanes_' + uniqueId];
        }

        mechSelect.addEventListener('change', () => {
            savedState['mech_' + uniqueId] = mechSelect.value;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(savedState));
        });

        maxLanesInput.addEventListener('input', () => {
            savedState['maxlanes_' + uniqueId] = maxLanesInput.value;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(savedState));
        });
    });
});
async function quickGenerateTime(btn) {
    if (!confirm("Berdasarkan durasi default, proses ini akan meng-generate waktu jadwal. Lanjutkan?")) return;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="animate-spin inline-block">⏳</span> Generating...';
    btn.disabled = true;

    try {
        const formData = new FormData();
        const getVal = (name, fallback) => localStorage.getItem('roll_gen_time_' + name) || fallback;

        for(let i=1; i<=5; i++) {
            formData.append(`start_times[${i}]`, getVal(`start_times[${i}]`, '07:30'));
            formData.append(`break_start_times[${i}]`, getVal(`break_start_times[${i}]`, '11:30'));
            formData.append(`break_end_times[${i}]`, getVal(`break_end_times[${i}]`, '13:00'));
        }
        const pd = getVal('pemula_duration', '');
        if (pd) formData.append('pemula_duration', pd);

        const res = await fetch(`<?= getenv('APP_URL') ?>/roll/admin/events/generate_schedule_time`, {
            method: 'POST',
            body: formData
        });
        const json = await res.json();
        
        if (json.success) {
            alert('Berhasil: Waktu perlombaan berhasil digenerate berdasarkan auto-seeding terakhir.');
            location.reload();
        } else {
            alert('Gagal: ' + (json.message || 'Gagal mengenerate waktu'));
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    } catch (e) {
        alert('Gagal: Terjadi kesalahan pada saat memproses response dari server.');
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}
</script>

<!-- MODAL MERGE CLASSES -->
<div id="modalMerge" class="fixed inset-0 z-[100] hidden">
    <div class="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onclick="document.getElementById('modalMerge').classList.add('hidden')"></div>
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
        <div class="p-6 bg-slate-50 border-b border-slate-200 flex justify-between items-center shrink-0">
            <div>
                <h3 class="text-lg font-black uppercase tracking-widest text-slate-800">🔗 Gabung Nomor Lomba (Hard Merge)</h3>
                <p class="text-xs text-slate-500 font-bold mt-1">Peserta akan dipindahkan permanen ke Kelas Target.</p>
            </div>
            <button type="button" onclick="document.getElementById('modalMerge').classList.add('hidden')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold">&times;</button>
        </div>
        <div class="p-6 overflow-y-auto">
            <form method="POST" action="<?= getenv('APP_URL') ?>/roll/admin/pelotons/merge_classes">
                <div class="mb-4">
                    <label class="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Kelas Target (Tujuan)</label>
                    <select name="target_class_id" required class="w-full border-slate-200 rounded-xl shadow-sm text-sm focus:ring-indigo-500 focus:border-indigo-500 font-bold text-slate-700">
                        <option value="">-- Pilih Kelas Target --</option>
                        <?php foreach($allClasses as $c): ?>
                            <option value="<?= $c['class_id'] ?>">
                                <?= htmlspecialchars(($c['custom_name'] ?: $c['group_name']) . ' - ' . $c['gender'] . ' - ' . $c['distance_name'] . ' (' . ($c['roller_name'] ?: 'Eksebisi') . ')') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Kelas Asal (Yang Akan Digabung & Dihapus)</label>
                    <div class="max-h-48 overflow-y-auto border border-slate-200 rounded-xl p-3 bg-slate-50 space-y-2">
                        <?php foreach($allClasses as $c): ?>
                            <label class="flex items-center gap-3 cursor-pointer p-2 hover:bg-white rounded-lg transition">
                                <input type="checkbox" name="source_class_ids[]" value="<?= $c['class_id'] ?>" class="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <span class="text-xs font-bold text-slate-700">
                                    <?= htmlspecialchars(($c['custom_name'] ?: $c['group_name']) . ' - ' . $c['gender'] . ' - ' . $c['distance_name'] . ' (' . ($c['roller_name'] ?: 'Eksebisi') . ')') ?>
                                    <span class="text-[9px] text-slate-400 ml-1">(<?= $c['total_entries'] ?> Atlet)</span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="mb-6">
                    <label class="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Nama Kelompok Umur Baru (Kustom)</label>
                    <input type="text" name="custom_name" required placeholder="Contoh: SENIOR, JUNIOR" class="w-full border-slate-200 rounded-xl shadow-sm text-sm focus:ring-indigo-500 focus:border-indigo-500 font-bold text-slate-800 uppercase">
                    <p class="text-[9px] text-slate-400 font-bold mt-1">Ini akan menggantikan nama Kelompok Umur (misal 'JUNIOR' menjadi 'SENIOR, JUNIOR') di buku hasil.</p>
                </div>

                <div class="flex justify-end gap-3 pt-4 border-t border-slate-100 mb-6">
                    <button type="button" onclick="document.getElementById('modalMerge').classList.add('hidden')" class="px-5 py-3 rounded-xl font-black text-xs uppercase tracking-widest text-slate-500 hover:bg-slate-100 transition">Tutup</button>
                    <button type="submit" onclick="return confirm('Yakin ingin menggabungkan? Semua entri dari Kelas Asal akan dipindahkan permanen ke Kelas Target, dan Kelas Asal akan dihapus.')" class="px-5 py-3 rounded-xl font-black text-xs uppercase tracking-widest bg-indigo-600 text-white shadow-lg hover:bg-indigo-700 transition">Proses Penggabungan</button>
                </div>
            </form>

            <!-- DAFTAR KELAS YANG SUDAH DIGABUNG / DIUBAH NAMANYA -->
            <?php
            $customClasses = array_filter($allClasses, function($c) {
                return !empty($c['custom_name']);
            });
            ?>
            <?php if(!empty($customClasses)): ?>
                <div class="mt-8 border-t-2 border-dashed border-slate-200 pt-6">
                    <h4 class="text-[11px] font-black uppercase tracking-widest text-slate-800 mb-4 flex items-center gap-2">
                        <span class="text-indigo-500">📝</span> Kelola Kelas Kustom (Hasil Gabungan)
                    </h4>
                    <div class="space-y-3">
                        <?php foreach($customClasses as $cc): ?>
                            <div class="bg-white border border-slate-200 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
                                <div>
                                    <h5 class="text-xs font-black text-slate-900"><?= htmlspecialchars($cc['custom_name']) ?></h5>
                                    <p class="text-[9px] text-slate-500 font-bold mt-1">Asli: <?= htmlspecialchars($cc['group_name']) ?> - <?= htmlspecialchars($cc['gender']) ?> - <?= htmlspecialchars($cc['distance_name']) ?></p>
                                </div>
                                <div class="flex gap-2 w-full md:w-auto mt-2 md:mt-0">
                                    <form method="POST" action="<?= getenv('APP_URL') ?>/roll/admin/pelotons/update_custom_name" class="flex gap-2 w-full md:w-auto">
                                        <input type="hidden" name="class_id" value="<?= $cc['class_id'] ?>">
                                        <input type="hidden" name="action" value="edit">
                                        <input type="text" name="custom_name" value="<?= htmlspecialchars($cc['custom_name']) ?>" required class="w-full md:w-48 text-xs border-slate-200 rounded-lg py-1 px-2 focus:border-indigo-500 focus:ring-indigo-500 font-bold text-slate-700 uppercase">
                                        <button type="submit" class="bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-600 font-bold text-[9px] uppercase tracking-widest px-3 py-1 rounded-lg transition shrink-0">Simpan</button>
                                    </form>
                                    <form method="POST" action="<?= getenv('APP_URL') ?>/roll/admin/pelotons/update_custom_name" onsubmit="return confirm('Yakin ingin mereset ke nama asli? (PERHATIAN: Atlet yang sudah dipindah TIDAK akan otomatis kembali ke kelas asalnya karena ini Hard Merge)')">
                                        <input type="hidden" name="class_id" value="<?= $cc['class_id'] ?>">
                                        <input type="hidden" name="action" value="reset">
                                        <button type="submit" class="bg-red-50 hover:bg-red-600 hover:text-white text-red-600 font-bold text-[9px] uppercase tracking-widest px-3 py-2 rounded-lg transition shrink-0" title="Reset Nama">✕</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>